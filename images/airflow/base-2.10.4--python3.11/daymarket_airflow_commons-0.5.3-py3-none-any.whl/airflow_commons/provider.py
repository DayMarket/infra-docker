from typing import Any, Dict, Final

_INTEGRATION_NAME: Final[str] = 'integration-name'
_PYTHON_MODULES: Final[str] = 'python-modules'


def get_provider_info() -> Dict[str, Any]:
    return {
        'package-name': 'daymarket-airflow-commons',
        'name': 'UZUM Airflow Commons',
        'description': 'UZUM package with common operators for airflow',
        'versions': ['0.1.25', '0.1.26', '0.2.0', '0.3.1', '0.3.7'],
        'additional-dependencies': ['apache-airflow>=2.8.0'],
        'operators': [
            {
                _INTEGRATION_NAME: 'ClickHouse',
                _PYTHON_MODULES: [
                    'airflow_commons.operators.clickhouse_execute_operator',
                    'airflow_commons.operators.file_to_clickhouse_operator',
                    'airflow_commons.operators.google_sheet_to_db_operator',
                    'airflow_commons.operators.postgres_to_clickhouse_operator',
                    'airflow_commons.operators.sql_to_file_operator',
                ],
            },
        ],
        'hooks': [
            {
                _INTEGRATION_NAME: 'ClickHouse',
                _PYTHON_MODULES: ['airflow_commons.hooks.clickhouse_hook'],
            },
        ],
        'connection-types': [
            {
                'hook-class-name': 'airflow_commons.hooks.clickhouse_hook.ClickHouseHook',
                'connection-type': 'clickhouse',
            },
        ],
    }
