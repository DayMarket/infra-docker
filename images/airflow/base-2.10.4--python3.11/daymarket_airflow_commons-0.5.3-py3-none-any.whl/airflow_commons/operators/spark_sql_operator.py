import os

from airflow.providers.cncf.kubernetes.operators.spark_kubernetes import SparkKubernetesOperator
from airflow.utils.context import Context

CONFIG_DIR = os.path.join(os.path.abspath(os.path.dirname(__file__)), "configs")


class SparkSqlOperator(SparkKubernetesOperator):
    template_fields = (*SparkKubernetesOperator.template_fields, "sql")
    template_ext = (*SparkKubernetesOperator.template_ext, ".sql")
    ui_color = "#ff9900"

    def __init__(
        self,
        *,
        sql: str,
        spark_repartition: int = 200,
        spark_resources_setting: str = "",
        hudi_output_path: str = "",
        hudi_hive_target_db: str = "",
        hudi_hive_target_table: str = "",
        hudi_key_columns: str = "",
        hudi_write_mode: str = "",
        hudi_options: str = "",
        clickhouse_target_table: str = "",
        clickhouse_write_batch_size: int = 10000,
        clickhouse_conn_id: str = "clickhouse_spark_sql_operator",
        s3_output_path: str = "",
        s3_output_format: str = "",
        **kwargs,
    ):
        """
        This operator executes given sql query on spark and can save the output dataframe in 1 or more locations:
            s3 text format : 's3_output_path' and 's3_output_format' should be set
            hudi table (s3 parquet) : 'hudi_target_table', 'hudi_target_db', 'hudi_output_path' should be set
            clickhouse table : 'clickhouse_target_table' should be set

        hudi_output_path [optional]: s3 location for output parquet files. If the target hive table already exists, this field should be empty
        hudi_hive_target_table [optional]: target hive table name. If the table doesn't exist yet, hive_output_path should be set also
        clickhouse_target_table [optional]: Clickhouse target table. The result of the sql is appended to this table.
        clickhouse_write_batch_size [optional]: Batch size when writing to Clickhouse
        clickhouse_conn_id [optional]: Airflow connection id for clickhouse
        s3_output_path [optional]: s3 location for output text files.
        s3_output_format [optional]: Output format for text files. Can be json or csv(delimeter=';', header=true)
        spark_resources_setting [optional]:
            Default spark settings are in Airflow variable 'spark_sql_operator_settings'
            You can specify your spark settings in Airflow variable in format:
                {"spark_event_log_bucket_name": "um-dev-spark-history",
                "hive_metastore_uris": "thrift://hive-metastore.svc-data-hive-metastore.svc.cluster.local:9083",
                "driver_cores": "1",
                "driver_memory": "4g",
                "executor_cores": "2",
                "executor_instances": "1",
                "executor_memory": "4g",
                "app_type": "data_apps"}
            and then pass Airflow variable name to spark_resources_setting

        """
        self.sql = sql
        with open(os.path.join(CONFIG_DIR, "spark_sql_operator_config.yaml"), "r") as app_file:
            application = app_file.read()

        application = application.replace("<spark_repartition>", str(spark_repartition))
        application = application.replace("<hudi_output_path>", hudi_output_path)
        application = application.replace("<hudi_hive_target_db>", hudi_hive_target_db)
        application = application.replace("<hudi_hive_target_table>", hudi_hive_target_table)
        application = application.replace("<hudi_key_columns>", hudi_key_columns)
        application = application.replace("<hudi_options>", hudi_options)
        application = application.replace("<hudi_write_mode>", hudi_write_mode)
        application = application.replace("<clickhouse_target_table>", clickhouse_target_table)
        application = application.replace("<clickhouse_write_batch_size>", str(clickhouse_write_batch_size))
        application = application.replace("<s3_output_path>", s3_output_path)
        application = application.replace("<s3_output_format>", s3_output_format)


        if clickhouse_target_table:
            application = application.replace("<clickhouse_host>", f"{{{{ conn.{clickhouse_conn_id}.host }}}}")
            application = application.replace("<clickhouse_port>", f"{{{{ conn.{clickhouse_conn_id}.port }}}}")
            application = application.replace("<clickhouse_login>", f"{{{{ conn.{clickhouse_conn_id}.login }}}}")
            application = application.replace("<clickhouse_password>", f"{{{{ conn.{clickhouse_conn_id}.password }}}}")

        if spark_resources_setting:
            application = application.replace(
                "var.json.spark_sql_operator_settings.", f"var.json.{spark_resources_setting}."
            )

        super().__init__(
            namespace="svc-data-spark-jobs",
            application_file=application,
            kubernetes_conn_id="spark_k8s",
            **kwargs,
        )

    def execute(self, context: Context):
        if self.sql.endswith(".sql"):
            try:
                with open(self.sql, "r") as query:
                    sql_query = query.read()
            except FileNotFoundError as error:
                self.log.error(f"Error {error}: path to sql file not found")
                raise error
        else:
            sql_query = self.sql
        self.application_file = self.application_file.replace("<sql>", sql_query.replace("\n", " "))
        super().execute(context)
