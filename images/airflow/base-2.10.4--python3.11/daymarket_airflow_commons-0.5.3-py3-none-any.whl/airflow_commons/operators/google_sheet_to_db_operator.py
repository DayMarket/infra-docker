import json
import os
from types import MappingProxyType
from typing import Any, Callable, Dict, List, Optional, Union

import numpy as np
import pandas as pd
from airflow.hooks.base import BaseHook
from airflow.models import BaseOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.utils.context import Context
from clickhouse_sqlalchemy import Table, engines, types
from google.oauth2 import service_account
from googleapiclient.discovery import Resource, build
from sqlalchemy import Column, MetaData

from airflow_commons.hooks.clickhouse_hook import ClickHouseHook
from airflow_commons.logic.entities.s3 import S3Arguments
from airflow_commons.logic.load.s3 import S3PandasLoader

DATATYPES = MappingProxyType({
    np.dtype('datetime64[ns]'): types.DateTime64,
    object: types.String,
    str: types.String,
    np.dtype('object_'): types.String,
    np.dtype('int64'): types.Int64,
    int: types.Int64,
    np.dtype('float64'): types.Float64,
    float: types.Float64,
    np.dtype('bool'): types.Boolean,
})

HEADER_RENAMING_STRATEGY_TYPE = Callable[[List[str]], List[str]]
CUSTOM_TRANSFORMATION_TYPE = Callable[[pd.DataFrame], pd.DataFrame]
SHEET_COLUMN_TYPE = Union[str, type]
SHEET_SCHEMA_TYPE = Union[SHEET_COLUMN_TYPE, Dict[str, SHEET_COLUMN_TYPE]]


class GSheetToClickhouseOperator(BaseOperator):
    """
    Operator that read Google Sheet and insert it into Clickhouse table.

    Creates a main table that will be truncated or recreated before inserting the data
    """

    TABLE_PATH = '/clickhouse/tables/{{shard}}/{database}/{table}'
    S3_PATH = '{{ dag.dag_id }}/{{ run_id }}'

    template_fields = ('sheet', 'table_name', 'headers', 'S3_PATH')
    template_ext = ()
    ui_color = '#188038'

    def __init__(
        self,
        *,
        spreadsheet_id: str,
        hook: ClickHouseHook,
        table_name: str,
        sheet: Optional[str] = None,
        sheet_schema: Optional[SHEET_SCHEMA_TYPE] = None,
        recreate: Optional[bool] = None,
        headers: Optional[int] = None,
        google_auth_conn_id: Optional[str] = None,
        header_renaming_strategy: Optional[HEADER_RENAMING_STRATEGY_TYPE] = None,
        columns_to_dayfirst: Optional[Dict[str, bool]] = None,
        custom_transformation: Optional[CUSTOM_TRANSFORMATION_TYPE] = None,
        **kwargs: Dict[str, Any],
    ) -> None:
        """
        Base constructor to create operator.

        Args:
            spreadsheet_id: id of Google spreadsheet - it is in url
            hook: hook for connecting to Clickhouse
            table_name: name of clickhouse table
            sheet: name of sheet
            sheet_schema: schema for pandas dataframe:
                https://pandas.pydata.org/docs/reference/api/pandas.DataFrame.astype.html
            recreate: if true, operator will drop table and create again
            headers: number of row, that contains headers, default 1
            google_auth_conn_id: connection of Google cloud that contains keyfile json
            header_renaming_strategy: strategy to rename column names of the source sheet.
                Should follow CH naming convention.
            columns_to_dayfirst: maps with column names and boolean flag for dayfirst option.
                Only applicable for timestamp columns
            custom_transformation: to give more control over transformation of a DataFrame
            **kwargs: additional keyword arguments for parent constructor of BaseOperator
        """
        super().__init__(**kwargs)
        self.spreadsheet_id = spreadsheet_id
        self.hook = hook
        self.table_name = table_name
        self.sheet = sheet or 'Лист1'
        self.sheet_schema = sheet_schema
        self.recreate = recreate or False
        self.headers = headers or 1
        self.header_renaming_strategy = header_renaming_strategy
        self.google_auth_conn_id = google_auth_conn_id or 'google_sheets_service_account'
        self.columns_to_dayfirst = columns_to_dayfirst or {}
        self.custom_transformation = custom_transformation
        self.s3_hook = S3Hook(aws_conn_id='airflow_bucket')

    @classmethod
    def get_service_sacc(cls, credentials_json: Dict[str, str]) -> Resource:
        """
        Method for getting service account from Google api to get spreadsheet.

        Args:
            credentials_json: dict with service_account credentials

        Returns:
            A Resource object with methods for interacting with the service.
        """
        scopes = ['https://www.googleapis.com/auth/spreadsheets']

        creds = service_account.Credentials.from_service_account_info(credentials_json, scopes=scopes)
        return build('sheets', 'v4', credentials=creds)

    def infer_types(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Method for detecting actual types of columns and trying to convert pandas Series to them.

        Methods pd.to_datetime and pd.to_numeric are using.

        Args:
            df: pandas Dataframe

        Returns:
            pandas Dataframe with new types of columns
        """
        self.log.info('start to casting datetime columns')
        for column in df.columns:
            if df[column].dtype == object:
                try:
                    # keep default values for all columns in case of column absence in the map
                    df[column] = pd.to_datetime(
                        df[column],
                        dayfirst=self.columns_to_dayfirst.get(column, False),
                    )
                except ValueError:
                    self.log.info(
                        'Column - {column_name} can not be casted to datetime, skip column'.format(
                            column_name=column,
                        ),
                    )
                    try:
                        df[column] = pd.to_numeric(df[column])
                    except ValueError:
                        self.log.info(
                            'Column - {column_name} can not be casted to numeric, skip column'.format(
                                column_name=column,
                            ),
                        )

        return df

    @classmethod
    def ge_ch_type_from_pandas(cls, series: pd.Series) -> types.common.ClickHouseTypeEngine:
        """
        Method for choose type from sqlalchemy engine types.

        Basically, need for detect Date columns.

        Args:
            series: Series of pandas dataframe

        Returns:
            ClickhouseTypeEngine that class of all clickhouse types
        """
        is_np_datetime = series.dtype == np.dtype('datetime64[ns]')

        if is_np_datetime and (series.dt.floor('d') == series).all():
            return types.Date
        return DATATYPES[series.dtype]

    def execute(self, context: Context) -> None:
        """
        Airflow method for running.

        Args:
            context: context of task
        """
        credentials_extra = json.loads(BaseHook.get_connection(self.google_auth_conn_id).get_extra())
        credentials = json.loads(credentials_extra.get('extra__google_cloud_platform__keyfile_dict'))
        service_acc = self.get_service_sacc(credentials)
        self.log.info('Got service account')

        self.log.info('trying to get data from spreadsheet')
        # It is set dynamically during service creation.
        spreadsheets_values = service_acc.spreadsheets().values()
        spreadsheet_content = spreadsheets_values.get(
            spreadsheetId=self.spreadsheet_id,
            range=self.sheet,
            valueRenderOption='UNFORMATTED_VALUE',
            dateTimeRenderOption='FORMATTED_STRING',
        )
        spreadsheet_json = spreadsheet_content.execute()
        self.log.info('got data from google spreadsheet')
        df = pd.DataFrame(
            spreadsheet_json['values'][1:],
            columns=self._rename_header_column_names_if_needed(
                spreadsheet_json['values'][self.headers - 1],
            ),
        )

        if self.custom_transformation:
            df = self.custom_transformation(df)

        if self.sheet_schema:
            df = df.astype(dtype=self.sheet_schema)
        else:
            df = self.infer_types(df)

        self.log.info(df.info())

        if not df.empty:
            file_key = os.path.join(self.S3_PATH, '{0}.csv'.format(self.table_name))
            loader = S3PandasLoader(
                S3Arguments(
                    bucket_name=self.s3_hook.conn_config.extra_config['bucket_name'],
                    file_key=file_key,
                    pandas_kwargs={},
                    s3_connection=self.s3_hook.get_conn(),
                ),
            )
            loader.load(df)
            self.log.info('File {file_key} successfully loaded to s3'.format(file_key=file_key))

            db_engine = self.hook.get_alchemy_engine()
            db_metadata = MetaData(bind=db_engine)

            columns = [
                Column(
                    'dt',
                    types.DateTime64(timezone='UTC'),
                ),
            ]
            for column in df.columns:
                columns.append(
                    Column(
                        column,
                        self.ge_ch_type_from_pandas(df[column]),
                    ),
                )

            table = Table(
                self.table_name,
                db_metadata,
                *columns,
                engines.ReplicatedMergeTree(
                    table_path=self.TABLE_PATH.format(
                        database=self.hook.database,
                        table=self.table_name,
                    ),
                    replica_name='{replica}',
                    partition_by=columns[0],
                    order_by=(columns[0],),
                ),
                clickhouse_cluster='{cluster}',
            )

            if self.recreate:
                self.log.info('Start recreating table')
                self.hook.run(
                    "DROP TABLE IF EXISTS {database}.{table_name} ON CLUSTER '{{cluster}}' SYNC".format(
                        database=self.hook.database,
                        table_name=self.table_name,
                    ),
                )
                self.log.info(
                    'Table {database}.{table_name} successfully dropped'.format(
                        database=self.hook.database,
                        table_name=self.table_name,
                    ),
                )

                table.create()

                self.log.info(
                    'Table {database}.{table_name} was successfully created'.format(
                        database=self.hook.database,
                        table_name=self.table_name,
                    ),
                )
            else:
                table.create(checkfirst=True)
                self.log.info('Start to truncate target table in Clickhouse')
                self.hook.run(
                    "TRUNCATE TABLE IF EXISTS {database}.{table_name} ON CLUSTER '{{cluster}}'".format(
                        database=self.hook.database,
                        table_name=self.table_name,
                    ),
                )
                self.log.info(
                    'Table {database}.{table_name} successfully truncated'.format(
                        database=self.hook.database,
                        table_name=self.table_name,
                    ),
                )

            # first we need to insert data to main table with current data in dpreadsheet
            self.log.info('Start loading dataframe into Clickhouse')
            rows_inserted = self.hook.insert_dataframe(
                query='INSERT INTO {database}.{table_name} (dt, {inserted_values}) VALUES'.format(
                    database=self.hook.database,
                    table_name=self.table_name,
                    inserted_values=', '.join(map(str, df.columns)),
                ),
                dataframe=df.assign(dt=context['logical_date'].to_datetime_string()),
            )
            self.log.info(
                '{rows_inserted} rows inserted into table {database}.{table_name}'.format(
                    rows_inserted=rows_inserted,
                    database=self.hook.database,
                    table_name=self.table_name,
                ),
            )

        self.log.info('There is no data, stop executing')

    def _rename_header_column_names_if_needed(self, header_column_names: List[str]) -> List[str]:
        if self.header_renaming_strategy:
            self.log.info(
                'Source header column names: {source_column_names}'.format(
                    source_column_names=header_column_names,
                ),
            )
            renamed = self.header_renaming_strategy(header_column_names)
            self.log.info(
                'Renamed header column names: {source_column_names}'.format(
                    source_column_names=renamed,
                ),
            )
            return renamed
        return header_column_names
