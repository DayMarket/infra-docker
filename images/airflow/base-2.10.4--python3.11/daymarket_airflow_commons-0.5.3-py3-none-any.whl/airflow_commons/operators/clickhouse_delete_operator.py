from typing import Any, Dict, Optional
from airflow.models import BaseOperator
from airflow.utils.context import Context
from airflow_commons.hooks.clickhouse_connect_hook import ClickHouseConnectHook
from clickhouse_connect.driver import Client
from clickhouse_connect.driver.query import QueryResult


class ClickhouseDeleteOperator(BaseOperator):
    """Operator to execute a DELETE statement on a ClickHouse table."""

    template_fields = ("table_name", "in_partition", "where")
    ui_color = "#fc0"

    def __init__(
        self,
        *,
        table_name: str,
        in_partition: Optional[str] = None,
        where: str,
        ch_hook: ClickHouseConnectHook,
        **kwargs: Dict[str, Any],
    ) -> None:
        """
        Base constructor to create operator.

        Args:
            table_name: Name of the ClickHouse table from which rows will be deleted.
            where: Conditions to apply in the WHERE clause (omit the "WHERE" keyword).
            in_partition: (Optional) Partition identifier to include in an IN PARTITION clause.
            ch_hook: An instance of ClickHouseConnectHook used to connect to ClickHouse.
            kwargs: Additional keyword arguments passed to the BaseOperator constructor.
        """
        super().__init__(**kwargs)
        self.hook = ch_hook
        self.table_name = table_name
        self.where = where
        self.in_partition = in_partition

    def execute(self, context: Context) -> None:
        client: Client = self.hook.get_conn()

        # Step 1: Check if data exists for the where clause
        if not self.where:
            raise ValueError("WHERE clause is required, but was not provided")

        data: QueryResult = client.query(
            f"SELECT 1 FROM {self.table_name} WHERE {self.where} LIMIT 1"
        )

        if not data.result_rows:
            self.log.warning(
                "No data found for the specified WHERE clause. Skipping deletion."
            )
            return

        # Step 2: Delete data if exists
        if self.in_partition is None:
            self.log.warning(
                "No argument 'in_partition' provided; this may lead to a full table scan. "
                "It is recommended to specify a partition id to optimize performance."
            )
            delete_query = f"DELETE FROM {self.table_name} WHERE {self.where} "
        else:
            delete_query = f"DELETE FROM {self.table_name} IN PARTITION '{self.in_partition}' WHERE {self.where} "
        delete_query += (
            "SETTINGS distributed_ddl_task_timeout = 1500, mutations_sync = 2;"
        )

        self.log.info(f"Running query: {delete_query}")

        try:
            client.command(delete_query)
            self.log.info("Delete query executed successfully.")
        except Exception as e:
            self.log.error(f"Failed to execute delete query: {e}")
            raise

        client.close()
        return
