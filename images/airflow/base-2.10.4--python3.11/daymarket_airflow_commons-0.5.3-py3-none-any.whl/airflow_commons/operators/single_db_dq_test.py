import math
import os
from typing import Any, Dict, Iterable, List, Optional, Union

import pandas as pd
import yaml
from airflow.models import BaseOperator, Variable
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.utils.context import Context

from airflow_commons.hooks.clickhouse_hook import ClickHouseHook
from airflow_commons.logic.alert.dq_alert import DQAlert
from airflow_commons.logic.entities.db_extractor_arguments import DBExtractorArguments
from airflow_commons.logic.entities.dq_alert_arguments import DQAlertArguments
from airflow_commons.logic.entities.single_db_dq_test import SingleDBDQTestArguments
from airflow_commons.logic.entities.slack_arguments import SlackArguments
from airflow_commons.logic.extract.db_extractor import DBExtractor
from airflow_commons.logic.single_db_dq_test.single_db_dq_test import SingleDBDQTest


class SingleDBDQTestOperator(BaseOperator):
    template_ext = ('.sql', '.yaml')

    template_fields = ('config', 'filepath',)

    def __init__(
            self,
            config: Union[str, Dict[str, Any]],
            db_hook: Union[PostgresHook, ClickHouseHook],
            s3_hook: S3Hook = S3Hook(aws_conn_id='s3_dq_bucket'),
            slack_channel: Optional[str] = 'C05DU55CG4U',
            slack_token: Optional[str] = Variable.get('dq_slack_token'),
            pd_to_csv_kwargs: Optional[Dict[str, str]] = None,
            *args: Iterable[Any],
            **kwargs: Dict[str, Any],
    ) -> None:
        super().__init__(*args, **kwargs)
        self.config = config
        self.db_hook = db_hook
        self.s3_hook = s3_hook
        self.s3_bucket_name = self.s3_hook.conn_config.extra_config['bucket_name']
        self.filepath = os.path.join('{{ dag.dag_id }}', '{{ run_id }}')
        self.slack_channel = slack_channel
        self.slack_token = slack_token
        self.pd_to_csv_kwargs = pd_to_csv_kwargs or {}

    def _parse_config(self) -> Dict[str, Any]:
        if isinstance(self.config, str):
            return yaml.safe_load(self.config)
        elif isinstance(self.config, dict):
            return self.config
        else:
            raise TypeError("Config should be either a YAML file path or a dictionary.")

    def execute(self, context: Context) -> None:
        parsed_config = self._parse_config()
        test_suite_name = parsed_config.get('test_suite')
        tests = parsed_config.get('tests', [])

        dataframes: List[Dict[str, Union[str, pd.DataFrame]]] = []
        message: str = ''
        success_count = 0

        for test in tests:
            test_name = test.get('name')
            display_name = test.get('display_name')
            sql = test.get('sql')

            if not all([test_name, display_name, sql]):
                raise ValueError("Each test in the configuration should have 'name', 'display_name', and 'sql' fields.")

            extractor = DBExtractor(
                DBExtractorArguments(
                    sql=sql,
                    db_hook=self.db_hook
                )
            )
            df = extractor.extract()

            dq_test = SingleDBDQTest(
                SingleDBDQTestArguments(
                    name=test_name,
                    df=df,
                    s3_hook=self.s3_hook,
                    file_key=os.path.join(self.filepath, f'{test_name}.csv'),
                    pd_to_csv_kwargs=self.pd_to_csv_kwargs,
                )
            )

            is_success = dq_test.check()
            if not is_success:
                dq_test.save_results()
                dataframes.append({'name': test_name, 'df': df})
                message += f"Тест *{display_name}* не пройден. :x:\n"
            else:
                message += f"Тест *{display_name}* пройден успешно. :white_check_mark:\n"
                success_count += 1

        total_tests = len(tests)
        failed_count = total_tests - success_count
        success_rate = math.floor(success_count / total_tests * 100)
        message = f"{total_tests} tests, {success_count} success, {failed_count} failed, success rate {success_rate}%\n\n" + message

        alert = DQAlert(
            DQAlertArguments(
                test_name=test_suite_name,
                slack_data=SlackArguments(
                    channel=self.slack_channel,
                    token=self.slack_token
                ),
                dataframes=dataframes,
                message=message
            )
        )
        alert.send_message()
