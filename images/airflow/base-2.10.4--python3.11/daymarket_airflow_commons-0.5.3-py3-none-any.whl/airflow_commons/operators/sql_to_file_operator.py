import pathlib
from typing import Any, Dict, Iterable, Optional, Union

import pandas
import pandas as pd
from airflow.exceptions import AirflowException
from airflow.models import BaseOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow.utils.context import Context

from airflow_commons.hooks.clickhouse_hook import ClickHouseHook
from airflow_commons.logic.entities.s3 import S3Arguments
from airflow_commons.logic.errors import CanNotSelectBothError
from airflow_commons.logic.functions.select import select_one_or_two
from airflow_commons.logic.load.s3 import S3PandasLoader


class SQLToFileOperator(BaseOperator):
    """Operator to execute query either in Postgresql or Clickhouse and load it to S3."""

    template_ext = ('.sql',)

    template_fields = ('sql', 'filename', 'filepath')

    def __init__(
        self,
        sql: str,
        filename: str,
        db_hook: Union[PostgresHook, ClickHouseHook],
        filepath: Optional[str] = None,
        s3_connection_id: Optional[str] = None,
        s3_bucket_name: Optional[str] = None,
        pd_to_csv_kwargs: Optional[Dict[str, str]] = None,
        pd_to_parquet_kwargs: Optional[Dict[str, str]] = None,
        *args: Iterable[Any],
        **kwargs: Dict[str, Any],
    ) -> None:
        """
        Base constructor to create operator.

        Args:
            sql: the SQL statement to be executed (str or path)
            filename: destination file name to save
            db_hook: hook to execute SQL
            filepath: destination file path to save
            s3_connection_id: airflow connection name to use it with hook
            s3_bucket_name: destination bucket name
            pd_to_csv_kwargs: dict of pandas.read_csv method arguments
            pd_to_parquet_kwargs: dict of pandas.read_parquet method arguments
            *args: additional arguments for parent constructor of BaseOperator
            **kwargs: additional keyword arguments for parent constructor of BaseOperator

        Raises:
            AirflowException: will be raised in case if CSV and parquet arguments will be provided
        """
        super().__init__(*args, **kwargs)
        self.sql = sql
        self.filename = filename
        self.db_hook = db_hook
        self.filepath = filepath or '{{ dag.dag_id }}/{{ run_id }}'
        self.s3_hook = S3Hook(aws_conn_id=s3_connection_id or 'airflow_bucket')
        self.s3_bucket_name = s3_bucket_name
        try:
            self._pandas_kwargs = select_one_or_two(pd_to_csv_kwargs, pd_to_parquet_kwargs, {})
        except CanNotSelectBothError as error:
            raise AirflowException('Only CSV or parquet can be loaded in the same time.') from error

    def execute(self, context: Context) -> None:
        df = self._execute_sql()
        file_key = str(pathlib.Path(self._strip_s3fs()) / self.filename)

        loader = S3PandasLoader(
            S3Arguments(
                bucket_name=self.s3_bucket_name or self.s3_hook.conn_config.extra_config['bucket_name'],
                file_key=file_key,
                pandas_kwargs=self._pandas_kwargs,
                s3_connection=self.s3_hook.get_conn(),
            ),
        )
        loader.load(df)

        self.log.info('File {file_key} successfully loaded to s3'.format(file_key=file_key))

    def _execute_sql(self) -> pandas.DataFrame:
        if not isinstance(self.db_hook, (ClickHouseHook, PostgresHook)):
            raise AirflowException('Postgres or Clickhouse are available')

        if self.sql.endswith('.sql'):
            df = self._try_to_open_and_execute()
        else:
            self.log.info('Start executing query:\n{query} in Postgres'.format(query=self.sql))
            df = self.db_hook.get_pandas_df(self.sql)

        self.log.info('DataFrame from query has {rows_amount} rows'.format(rows_amount=df.shape[0]))
        self.log.info('First 5 rows of dataframe\n: {first_five_rows}'.format(first_five_rows=df.head()))
        return df

    def _try_to_open_and_execute(self) -> pd.DataFrame:
        with open(self.sql, 'r') as query:
            self.log.info(
                'Start executing query from file_path: {query_path}'.format(
                    query_path=self.sql,
                ),
            )
            return self.db_hook.get_pandas_df(query.read())

    def _strip_s3fs(self) -> str:
        return self.filepath.strip('/').replace('opt/airflow/s3fs/', '')
