import pathlib
from collections import namedtuple
from typing import Any, Callable, Dict, Iterable, List, Optional

import pandas as pd
from airflow import AirflowException
from airflow.models import BaseOperator
from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.utils.context import Context

from airflow_commons.hooks.clickhouse_hook import ClickHouseHook
from airflow_commons.logic.entities.s3 import S3Arguments
from airflow_commons.logic.errors import CanNotSelectBothError
from airflow_commons.logic.extract.s3 import S3PandasExtractor
from airflow_commons.logic.functions.select import select_one_or_two

TablePartition = namedtuple('TablePartition', 'table partition')

_OPTIMIZE_QUERY = """OPTIMIZE TABLE {table} ON CLUSTER '{{cluster}}' PARTITION {partition} FINAL
                                  SETTINGS distributed_ddl_task_timeout = 1500;"""


class FileToClickhouseOperator(BaseOperator):
    """Operator to insert data from s3 to clickhouse in csv or parquet format."""

    template_ext = ('.sql',)

    template_fields = (
        'target_table',
        'filename',
        'filepath',
        'partitions_to_optimize',
    )

    def __init__(
        self,
        ch_hook: ClickHouseHook,
        target_table: str,
        filename: str,
        filepath: Optional[str] = None,
        column_list: Optional[Iterable[str]] = None,
        truncate: bool = False,
        transform_df: Callable[[pd.DataFrame, Context], pd.DataFrame] = None,
        query_id: Optional[str] = None,
        external_tables: Optional[List[Dict]] = None,
        partitions_to_optimize: Optional[List[TablePartition]] = None,
        pd_read_csv_kwargs: Optional[Dict[str, str]] = None,
        pd_read_parquet_kwargs: Optional[Dict[str, str]] = None,
        s3_connection_id: Optional[str] = None,
        s3_bucket_name: Optional[str] = None,
        *args: Iterable[Any],
        **kwargs: Dict[str, Any],
    ):
        """
        Base constructor to create operator.

        Args:
            ch_hook: connection id in airflow to clickhouse db
            target_table: table in clickhouse to fill data
            filename: name of file in filesystem
            filepath: path to download file from s3
            column_list: list of column_names to use in insert query to clickhouse. default all columns
            truncate: if specified then target table will be truncated
            transform_df: python function to do transformation with dataframe
            query_id: the query identifier. It will be generated in case of absence. String but real type is uuid
            external_tables: external tables that can be used in query
            partitions_to_optimize: partitions that will execute optimize in clickhouse
            pd_read_csv_kwargs: dict of pandas.read_csv method arguments
            pd_read_parquet_kwargs: dict of pandas.read_parquet method arguments
            s3_connection_id: airflow connection name to use it with hook
            s3_bucket_name: destination bucket name
            *args: additional arguments for parent constructor of BaseOperator
            **kwargs: additional keyword arguments for parent constructor of BaseOperator

        Raises:
            AirflowException: will be raised in case if CSV and parquet arguments will be provided
        """
        super().__init__(*args, **kwargs)

        self.hook = ch_hook
        self.target_table = target_table
        self.filename = filename
        self.filepath = filepath or '{{ dag.dag_id }}/{{ run_id }}'
        self.column_list = column_list or ('*',)
        self.truncate = truncate
        self.transform_df = transform_df
        self.query_id = query_id
        self.external_tables = external_tables
        self.partitions_to_optimize = partitions_to_optimize or []
        self.s3_hook = S3Hook(aws_conn_id=s3_connection_id or 'airflow_bucket')
        self.s3_bucket_name = s3_bucket_name
        try:
            self._pandas_kwargs = select_one_or_two(pd_read_csv_kwargs, pd_read_parquet_kwargs, {})
        except CanNotSelectBothError as error:
            raise AirflowException('Only CSV or parquet can be read in the same time.') from error

    def execute(self, context: Context) -> None:
        file_key = str(pathlib.Path(self._strip_s3fs()) / self.filename)

        extractor = S3PandasExtractor(
            S3Arguments(
                bucket_name=self.s3_bucket_name or self.s3_hook.conn_config.extra_config['bucket_name'],
                file_key=file_key,
                pandas_kwargs=self._pandas_kwargs,
                s3_connection=self.s3_hook.get_conn(),
            ),
        )

        df = extractor.extract()

        if df.empty:
            self.log.info('Nothing to read from: {file_key}'.format(file_key=file_key))
        else:
            self.log.info(
                'Dataframe from {filepath} has {rows_amount} rows'.format(
                    filepath=self.filepath,
                    rows_amount=df.shape[0],
                ),
            )
            self.log.info(
                'First 5 rows of dataframe\n: {first_five_rows}'.format(
                    first_five_rows=df.head(),
                ),
            )

            if self.transform_df:
                old_shape = df.shape
                self.log.info(
                    'Shape before transforming - {old_shape}'.format(
                        old_shape=old_shape,
                    ),
                )
                df = self.transform_df(df, context)
                self.log.info(
                    'Dataframe was transformed from {old_shape} to {new_shape}'.format(
                        old_shape=old_shape,
                        new_shape=df.shape,
                    ),
                )

            if self.truncate:
                self.log.info('Start to truncate target table in Clickhouse')
                self.hook.run(
                    "TRUNCATE TABLE {target_table} ON CLUSTER '{{cluster}}'".format(
                        target_table=self.target_table,
                    ),
                )
                self.log.info('Table successfully truncated')

            self.log.info('Start loading dataframe into Clickhouse')

            rows_inserted = self.hook.insert_dataframe(
                query='INSERT INTO {target_table} ({inserted_values}) VALUES'.format(
                    target_table=self.target_table,
                    inserted_values=','.join(map(str, self.column_list)),
                ),
                dataframe=df,
                external_tables=self.external_tables,
                query_id=self.query_id,
            )
            self.log.info(
                '{rows_inserted} rows inserted into table {target_table}'.format(
                    rows_inserted=rows_inserted,
                    target_table=self.target_table,
                ),
            )

            # Call OPTIMIZE. Useful in case of ReplacingMergeTree Engine
            # when we need to ensure that no duplicates are to remain after ETL
            for table, partition in self.partitions_to_optimize:
                self.log.info(
                    'Executing optimize on table {table} and partition {partition}'.format(
                        table=table,
                        partition=partition,
                    ),
                )
                self.hook.run(_OPTIMIZE_QUERY.format(table=table, partition=partition))

    def _strip_s3fs(self) -> str:
        return self.filepath.strip('/').replace('opt/airflow/s3fs/', '')
