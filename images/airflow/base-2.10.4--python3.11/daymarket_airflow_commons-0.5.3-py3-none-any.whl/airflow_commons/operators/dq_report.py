from typing import Any, Dict, Iterable, Optional, Type

from airflow.models import BaseOperator, Variable
from airflow.utils.context import Context

from airflow_commons.logic.alert.dq_alert import DQAlert
from airflow_commons.logic.base_dq_report.base_dq_report import BaseDQReport
from airflow_commons.logic.entities.base_dq_report_arguments import BaseDQReportArguments
from airflow_commons.logic.entities.dq_alert_arguments import DQAlertArguments
from airflow_commons.logic.entities.dq_report_result import DQReportResult
from airflow_commons.logic.entities.enums import Source
from airflow_commons.logic.entities.slack_arguments import SlackArguments


class DQReportOperator(BaseOperator):

    def __init__(
        self,
        report_name: str,
        report: Type[BaseDQReport],
        slack_channel: Optional[str] = 'C05DU55CG4U',
        *args: Iterable[Any],
        **kwargs: Dict[str, Any],
    ) -> None:
        super().__init__(*args, **kwargs)
        self.report_name = report_name
        self.report = report
        self.slack_channel = slack_channel
        self.slack_token = Variable.get('dq_slack_token')
        self.sources = Source

    def execute(self, context: Context) -> None:
        reporter = self.report(
            BaseDQReportArguments(
                name=self.report_name,
                sources=self.sources,
                context=context,
            )
        )
        dq_result: DQReportResult = reporter.execute()
        if not dq_result.success:
            alert = DQAlert(
                DQAlertArguments(
                    test_name=self.report_name,
                    slack_data=SlackArguments(
                        channel=self.slack_channel,
                        token=self.slack_token,
                    ),
                    dataframes=dq_result.dataframes,
                    message=dq_result.message,
                )
            )
            alert.send_message()
