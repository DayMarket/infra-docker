from collections import namedtuple
from typing import Any, Dict, Iterable, List, Optional

from airflow.hooks.base import BaseHook
from airflow.models import BaseOperator
from airflow.utils.context import Context

from airflow_commons.hooks.clickhouse_connect_hook import ClickHouseConnectHook

TablePartition = namedtuple('TablePartition', 'table partition')

_OPTIMIZE_QUERY = """OPTIMIZE TABLE {table} ON CLUSTER '{{cluster}}' PARTITION {partition} FINAL
                                  SETTINGS distributed_ddl_task_timeout = 1500;"""


class ClickhouseToClickhouseOperator(BaseOperator):
    """Operator to transfer data from Clickhouse-source cluster using sql query to Clickhouse-dest cluster table."""

    template_fields = ('sql', 'partitions_to_optimize')
    template_fields_renderers = {'sql': 'sql'}
    template_ext = ('.sql',)

    def __init__(
        self,
        *,
        sql: str,
        clickhouse_source_conn_name: str,
        clickhouse_dest_conn_name: str,
        clickhouse_dest_schema: str,
        clickhouse_dest_table: str,
        column_list: Optional[Iterable[str]] = None,
        truncate: Optional[bool] = False,
        partitions_to_optimize: Optional[List[TablePartition]] = None,
        **kwargs: Dict[str, Any],
    ) -> None:
        """
        Base constructor to create operator.
        Args:
            sql: the sql statement to be executed (str) or path to sql file
            clickhouse_source_conn_name: name of clickhouse connection for source in airflow
            clickhouse_dest_conn_name: name of clickhouse connection for dest in airflow
            clickhouse_dest_table: table name in clickhouse to fill data for destination
            clickhouse_dest_schema: schema name in clickhouse to fill data for destination
            column_list: list of column_names to use in insert query to clickhouse. default all columns
            truncate: if specified then target table will be truncated
            partitions_to_optimize: partitions that will execute optimize in clickhouse
            **kwargs: additional keyword arguments for parent constructor of BaseOperator

        Для коннекшна clickhouse_source_conn_name необходимо создавать пользователя в clickhouse с следующими опцуиями:
        1. выставить параметр readonly=0
        2. grant CREATE TEMPORARY TABLE, REMOTE ON
        """
        super().__init__(**kwargs)
        self.sql = sql
        self.clickhouse_dest_table = clickhouse_dest_table
        self.column_list = column_list or ('*',)
        self.truncate = truncate
        self.clickhouse_source_conn_name = clickhouse_source_conn_name
        self.clickhouse_dest_conn_name = clickhouse_dest_conn_name
        self.clickhouse_dest_schema = clickhouse_dest_schema
        self.clickhouse_dest_table = clickhouse_dest_table
        self.partitions_to_optimize: List[TablePartition] = partitions_to_optimize or []

    def execute(self, context: Context) -> None:
        self.ch_dest_conn = BaseHook.get_connection(self.clickhouse_dest_conn_name)
        self.clickhouse_dest_hook = ClickHouseConnectHook(
            clickhouse_conn_id=self.clickhouse_dest_conn_name
        )
        self.clickhouse_source_hook = ClickHouseConnectHook(
            clickhouse_conn_id=self.clickhouse_source_conn_name
        )
        if self.truncate:
            self.clickhouse_dest_hook.run(
                'TRUNCATE TABLE {clickhouse_dest_schema}.{clickhouse_dest_table}'.format(
                    clickhouse_dest_schema=self.clickhouse_dest_schema,
                    clickhouse_dest_table=self.clickhouse_dest_table,
                ),
            )

        self.log.info('Start selecting data from Clickhouse-source')
        if self.sql.endswith('.sql'):
            try:
                self._try_to_open_and_execute()
            except FileNotFoundError as error:
                self.log.error(
                    'Error {error}: path to sql file not found'.format(
                        error=self.sql,
                    ),
                )
                raise error
        else:
            self.log.info(
                'Start generating SQL migration query:\n{sql}'.format(
                    sql=self.sql,
                ),
            )
            names_of_columns = ','.join(map(str, self.column_list))
            migration_query = f"""
                                INSERT INTO TABLE FUNCTION remote('{self.ch_dest_conn.host}:{self.ch_dest_conn.port}', 
                                                                  '{self.clickhouse_dest_schema}', 
                                                                  '{self.clickhouse_dest_table}', 
                                                                  '{self.ch_dest_conn.login}', 
                                                                  '{self.ch_dest_conn.password}' )
                                ({names_of_columns})
                                {self.sql}
            """
            self.log.info(
                'Start inserting data to Clickhouse-dest SQL migration-query from file_path: {migration_query}'.format(
                    migration_query=migration_query,
                ),
            )
            result = self.clickhouse_source_hook.run(migration_query)
            self.log.info(
                'Result of migaration-query request`: {result}'.format(
                    result=result,
                ),
            )

            # Call OPTIMIZE. Useful in case of ReplacingMergeTree Engine
            # when we need to ensure that no duplicates are to remain after ETL
            for table, partition in self.partitions_to_optimize:
                self.log.info(
                    'Executing optimize on table {table} and partition {partition}'.format(
                        table=table,
                        partition=partition,
                    ),
                )
                self.clickhouse_hook.run(_OPTIMIZE_QUERY.format(table=table, partition=partition))

    def _try_to_open_and_execute(self) -> None:
        with open(self.sql, 'r') as query:
            self.log.info(
                'Start executing Clickhouse-source SQL query from file_path: {query_path}'.format(
                    query_path=self.sql,
                ),
            )
            names_of_columns = ','.join(map(str, self.column_list))
            migration_query = f"""
                                INSERT INTO TABLE FUNCTION remote('{self.ch_dest_conn.host}:{self.ch_dest_conn.port}', 
                                                                  '{self.clickhouse_dest_schema}', 
                                                                  '{self.clickhouse_dest_table}', 
                                                                  '{self.ch_dest_conn.login}', 
                                                                  '{self.ch_dest_conn.password}')
                                ({names_of_columns})                                        
                                {query.read()}
            """
            self.log.info(
                'Start inserting data to Clickhouse-dest SQL migration-query from file_path: {migration_query}'.format(
                    migration_query=migration_query,
                ),
            )
            result = self.clickhouse_source_hook.run(migration_query)
            self.log.info(
                'Result of migration-query request`: {result}'.format(
                    result=result,
                ),
            )
