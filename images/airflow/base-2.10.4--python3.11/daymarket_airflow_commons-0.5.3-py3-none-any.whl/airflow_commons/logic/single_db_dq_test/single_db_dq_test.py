from abc import ABC

from airflow_commons.logic.entities.s3 import S3Arguments
from airflow_commons.logic.entities.single_db_dq_test import SingleDBDQTestArguments
from airflow_commons.logic.interfaces.dq_test import DQTest
from airflow_commons.logic.load.s3 import S3PandasLoader


class SingleDBDQTest(DQTest, ABC):
    def __init__(self, arguments: SingleDBDQTestArguments) -> None:
        self.arguments = arguments

    def check(self) -> bool:
        return self.arguments.df.empty

    def save_results(self) -> None:
        loader = S3PandasLoader(
            S3Arguments(
                bucket_name=self.arguments.s3_hook.conn_config.extra_config['bucket_name'],
                file_key=self.arguments.file_key,
                pandas_kwargs=self.arguments.pd_to_csv_kwargs,
                s3_connection=self.arguments.s3_hook.get_conn(),
            ),
        )
        loader.load(self.arguments.df)
