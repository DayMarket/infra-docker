from io import BytesIO

import pandas as pd


def _save_to_buffer(dataframe: pd.DataFrame) -> BytesIO:
    buffer = BytesIO()
    dataframe.to_csv(path_or_buf=buffer, index=False, encoding='UTF-8')
    buffer.seek(0)
    return buffer
