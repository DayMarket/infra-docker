from dataclasses import dataclass
from typing import Dict, Optional

import pandas as pd
from airflow.providers.amazon.aws.hooks.s3 import S3Hook


@dataclass
class SingleDBDQTestArguments:
    name: str
    df: pd.DataFrame
    s3_hook: S3Hook
    file_key: str
    pd_to_csv_kwargs: Optional[Dict[str, str]]
