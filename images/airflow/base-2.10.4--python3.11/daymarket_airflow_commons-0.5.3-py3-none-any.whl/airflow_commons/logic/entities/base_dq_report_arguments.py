from dataclasses import dataclass
from typing import Type

from airflow.utils.context import Context

from airflow_commons.logic.entities.enums import Source


@dataclass
class BaseDQReportArguments:
    name: str
    sources: Type[Source]
    context: Context
