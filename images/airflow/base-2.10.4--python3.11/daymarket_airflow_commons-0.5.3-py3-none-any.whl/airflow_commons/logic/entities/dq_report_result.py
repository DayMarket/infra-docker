from dataclasses import dataclass
from typing import Dict, List, Optional

import pandas as pd


@dataclass
class DQReportResult:
    message: str
    success: bool
    dataframes: Optional[List[Dict[str, pd.DataFrame]]] = None
