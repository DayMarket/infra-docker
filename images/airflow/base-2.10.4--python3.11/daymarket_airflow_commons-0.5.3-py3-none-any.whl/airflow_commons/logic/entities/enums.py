from enum import Enum

from airflow.providers.amazon.aws.hooks.s3 import S3Hook
from airflow.providers.postgres.hooks.postgres import PostgresHook

from airflow_commons.hooks.clickhouse_hook import ClickHouseHook


class Source(Enum):
    CH_HOOK: ClickHouseHook = ClickHouseHook(clickhouse_conn_id='clickhouse_dq')
    APIDB_HOOK: PostgresHook = PostgresHook(postgres_conn_id='postgres_apidb_dq')
    WMS_ORDER_HOOK: PostgresHook = PostgresHook(postgres_conn_id='postgres_wms_order_dq')
    WMS_DELIVERY_HOOK: PostgresHook = PostgresHook(postgres_conn_id='postgres_wms_delivery_dq')
    S3_HOOK: S3Hook = S3Hook(aws_conn_id='s3_dq_bucket')
