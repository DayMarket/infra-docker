from dataclasses import dataclass
from typing import Union

from airflow.providers.postgres.hooks.postgres import PostgresHook

from airflow_commons.hooks.clickhouse_hook import ClickHouseHook


@dataclass
class DBExtractorArguments:
    sql: str
    db_hook: Union[ClickHouseHook, PostgresHook]
