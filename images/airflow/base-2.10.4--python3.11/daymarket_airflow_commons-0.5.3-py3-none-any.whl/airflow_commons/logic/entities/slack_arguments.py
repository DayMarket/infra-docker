from dataclasses import dataclass


@dataclass
class SlackArguments:
    token: str
    channel: str
