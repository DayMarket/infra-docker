from dataclasses import dataclass
from typing import Dict, List, Optional

import pandas as pd

from airflow_commons.logic.entities.slack_arguments import SlackArguments


@dataclass
class DQAlertArguments:
    test_name: str
    slack_data: SlackArguments
    dataframes: Optional[List[Dict[str, pd.DataFrame]]] = None
    message: Optional[str] = None
