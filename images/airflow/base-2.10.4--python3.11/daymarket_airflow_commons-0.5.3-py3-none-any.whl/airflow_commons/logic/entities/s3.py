import typing
from dataclasses import dataclass

from mypy_boto3_s3 import S3Client


@dataclass
class S3Arguments:
    bucket_name: str
    file_key: str
    pandas_kwargs: typing.Dict[str, typing.Any]
    s3_connection: S3Client
