import logging

import pandas as pd
from airflow.exceptions import AirflowException
from airflow.providers.postgres.hooks.postgres import PostgresHook

from airflow_commons.hooks.clickhouse_hook import ClickHouseHook
from airflow_commons.logic.entities.db_extractor_arguments import DBExtractorArguments
from airflow_commons.logic.interfaces.extract import Extractor

logger = logging.getLogger(__name__)


class DBExtractor(Extractor[pd.DataFrame]):
    def __init__(self, arguments: DBExtractorArguments) -> None:
        self.arguments = arguments

    def extract(self) -> pd.DataFrame:
        return self._execute_sql()

    def _execute_sql(self) -> pd.DataFrame:
        if not isinstance(self.arguments.db_hook, (ClickHouseHook, PostgresHook)):
            raise AirflowException('Postgres or Clickhouse are available')
    
        if self.arguments.sql.endswith('.sql'):
            df = self._try_to_open_and_execute()
        else:
            logger.info('Start executing query:\n{query} in Postgres'.format(query=self.arguments.sql))
            df = self.arguments.db_hook.get_pandas_df(self.arguments.sql)
    
        logger.info('DataFrame from query has {rows_amount} rows'.format(rows_amount=df.shape[0]))
        logger.info('First 5 rows of dataframe\n: {first_five_rows}'.format(first_five_rows=df.head()))

        return df

    def _try_to_open_and_execute(self) -> pd.DataFrame:
        with open(self.arguments.sql, 'r') as query:
            logger.info(
                'Start executing query from file_path: {query_path}'.format(
                    query_path=self.arguments.sql,
                ),
            )
            return self.arguments.db_hook.get_pandas_df(query.read())
