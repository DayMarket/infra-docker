import io
import pathlib

import pandas
from mypy_boto3_s3.type_defs import GetObjectOutputTypeDef

from airflow_commons.logic.entities.s3 import S3Arguments
from airflow_commons.logic.errors import NonExistentFileKeyError
from airflow_commons.logic.interfaces.extract import Extractor


class S3PandasExtractor(Extractor[pandas.DataFrame]):
    _strategies = {
        '.csv': pandas.read_csv,
        '.parquet': pandas.read_parquet,
    }

    def __init__(self, arguments: S3Arguments) -> None:
        self._arguments = arguments

    def extract(self) -> pandas.DataFrame:
        try:
            s3_object = self._get_s3_object()
        except self._arguments.s3_connection.exceptions.NoSuchKey as error:
            raise NonExistentFileKeyError() from error
        return self._convert_to_pandas(s3_object)

    def _get_s3_object(self) -> GetObjectOutputTypeDef:
        return self._arguments.s3_connection.get_object(
            Bucket=self._arguments.bucket_name,
            Key=self._arguments.file_key,
        )

    def _convert_to_pandas(self, s3_object: GetObjectOutputTypeDef) -> pandas.DataFrame:
        if s3_object['ContentLength'] > 0:
            extension = pathlib.Path(self._arguments.file_key).suffixes[0]
            strategy = self._strategies[extension]
            return strategy(
                io.BytesIO(
                    s3_object['Body'].read(),
                ),
                **self._arguments.pandas_kwargs,
            )
        return pandas.DataFrame()
