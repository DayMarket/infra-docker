from typing import Optional, TypeVar

from airflow_commons.logic.errors import CanNotSelectBothError

SELECTION_TYPE = TypeVar('SELECTION_TYPE')


def select_one_or_two(
    one: Optional[SELECTION_TYPE],
    two: Optional[SELECTION_TYPE],
    default: SELECTION_TYPE,
) -> SELECTION_TYPE:
    if one is not None and two is not None:
        raise CanNotSelectBothError()
    elif one is not None:
        return one
    return two or default
