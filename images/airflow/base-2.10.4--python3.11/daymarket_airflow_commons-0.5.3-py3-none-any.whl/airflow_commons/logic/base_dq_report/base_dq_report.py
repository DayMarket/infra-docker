from abc import ABC

from airflow_commons.logic.entities.base_dq_report_arguments import BaseDQReportArguments
from airflow_commons.logic.entities.dq_report_result import DQReportResult
from airflow_commons.logic.interfaces.executor import Executor


class BaseDQReport(Executor, ABC):
    def __init__(self, arguments: BaseDQReportArguments) -> None:
        self.arguments = arguments

    def execute(self) -> DQReportResult:
        """
        Override this method for executing main logic of your report and return bool as result
        and string to send it to slack
        :return: bool and string
        """
        raise NotImplementedError()


