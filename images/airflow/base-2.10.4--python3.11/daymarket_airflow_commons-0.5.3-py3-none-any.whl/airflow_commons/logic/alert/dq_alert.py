from slack_sdk import WebClient

from airflow_commons.logic.entities.dq_alert_arguments import DQAlertArguments
from airflow_commons.logic.utils.files import _save_to_buffer


class DQAlert:
    def __init__(self, arguments: DQAlertArguments) -> None:
        self.arguments = arguments

    def get_client(self):
        return WebClient(self.arguments.slack_data.token)

    def send_message(self):
        client = self.get_client()
        message = f"*{self.arguments.test_name}.*\n\n" + (self.arguments.message if self.arguments.message else "")
        file_uploads = []
        if self.arguments.dataframes:
            if len(self.arguments.dataframes) > 1:
                for idx, df in enumerate(self.arguments.dataframes):
                    buffer = _save_to_buffer(dataframe=df.get('df'))
                    filename = f"{df.get('name')}.csv"
                    file_uploads.append({'file': buffer, 'title': filename})
                client.files_upload_v2(
                    channel=self.arguments.slack_data.channel,
                    initial_comment=message,
                    file_uploads=file_uploads
                )
            else:
                buffer = _save_to_buffer(dataframe=self.arguments.dataframes[0].get('df'))
                filename = f"{self.arguments.dataframes[0].get('name')}.csv"
                client.files_upload_v2(
                    channel=self.arguments.slack_data.channel,
                    initial_comment=message,
                    file=buffer,
                    filename=filename
                )
        else:
            client.chat_postMessage(
                channel=self.arguments.slack_data.channel,
                text=message,
            )
