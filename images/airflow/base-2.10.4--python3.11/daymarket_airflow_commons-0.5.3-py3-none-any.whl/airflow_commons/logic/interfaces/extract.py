import abc
from typing import Generic, TypeVar

RETURNED_TYPE = TypeVar('RETURNED_TYPE')


class Extractor(Generic[RETURNED_TYPE]):
    @abc.abstractmethod
    def extract(self) -> RETURNED_TYPE:
        """Interface that each extractor should follow."""
