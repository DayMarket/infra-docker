import abc
from typing import Generic, TypeVar

LOADED_TYPE = TypeVar('LOADED_TYPE')


class Loader(Generic[LOADED_TYPE]):
    @abc.abstractmethod
    def load(self, entity: LOADED_TYPE):
        """
        Interface that each loader should follow.

        Args:
            entity: to load to the destination storage.
        """
