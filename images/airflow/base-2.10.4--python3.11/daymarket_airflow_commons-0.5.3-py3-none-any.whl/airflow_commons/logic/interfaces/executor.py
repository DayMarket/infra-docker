import abc
from typing import Generic, TypeVar

RETURNED_TYPE = TypeVar('RETURNED_TYPE')


class Executor(Generic[RETURNED_TYPE], metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def execute(self) -> RETURNED_TYPE:
        """Override this method for executing the main logic"""
