import abc
from typing import Generic, TypeVar

RETURNED_TYPE = TypeVar('RETURNED_TYPE')


class DQTest(Generic[RETURNED_TYPE], metaclass=abc.ABCMeta):
    @abc.abstractmethod
    def check(self) -> RETURNED_TYPE:
        """Interface for checking if test is successful"""

    @abc.abstractmethod
    def save_results(self) -> RETURNED_TYPE:
        """Interface for saving dataframe"""
