import io
import pathlib
import typing

import pandas

from airflow_commons.logic.entities.s3 import S3Arguments
from airflow_commons.logic.interfaces.load import Loader

BUFFER = typing.Union[io.StringIO, io.BytesIO]
PANDAS_TO_BUFFER_STRATEGY = typing.Callable[[pandas.DataFrame], BUFFER]


class S3PandasLoader(Loader[pandas.DataFrame]):
    def __init__(self, arguments: S3Arguments) -> None:
        self._arguments = arguments

        self._strategies: typing.Dict[str, PANDAS_TO_BUFFER_STRATEGY] = {
            '.csv': self._csv_to_buffer,
            '.parquet': self._parquet_to_buffer,
        }

    def load(self, entity: pandas.DataFrame) -> None:
        buffer = self._save_to_buffer(entity)
        return self._load_to_s3(buffer)

    def _save_to_buffer(self, entity: pandas.DataFrame) -> io.BytesIO:
        extension = pathlib.Path(self._arguments.file_key).suffix
        strategy = self._strategies[extension]
        return strategy(entity)

    def _load_to_s3(self, buffer: io.BytesIO) -> None:
        buffer.seek(0)
        self._arguments.s3_connection.put_object(
            Bucket=self._arguments.bucket_name,
            Key=self._arguments.file_key,
            Body=buffer.read(),
        )
        buffer.close()

    def _csv_to_buffer(self, entity: pandas.DataFrame) -> io.StringIO:
        buffer = io.StringIO()
        entity.to_csv(buffer, **self._arguments.pandas_kwargs)
        buffer.seek(0)
        return buffer

    def _parquet_to_buffer(self, entity: pandas.DataFrame) -> io.BytesIO:
        buffer = io.BytesIO()
        entity.to_parquet(buffer, **self._arguments.pandas_kwargs)
        buffer.seek(0)
        return buffer
