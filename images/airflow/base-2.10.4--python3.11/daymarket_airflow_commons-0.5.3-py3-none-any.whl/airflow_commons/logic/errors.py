class NonExistentFileKeyError(Exception):
    """Will be raised in case of absence of file ky on s3."""


class CanNotSelectBothError(Exception):
    """Will be raised in case of if either are not None."""
