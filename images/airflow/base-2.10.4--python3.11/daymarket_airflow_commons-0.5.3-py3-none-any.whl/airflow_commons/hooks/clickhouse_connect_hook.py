from typing import Any, Dict, Iterable, List, Optional, Union, Sequence

import clickhouse_connect
import pandas as pd
import warnings
from airflow.hooks.base import BaseHook
from airflow.models import Connection
from airflow_commons.hooks.clickhouse_hook import ClickHouseHook
from clickhouse_connect.driver import Client
from clickhouse_connect.driver.summary import QuerySummary
from sqlalchemy import create_engine
from sqlalchemy.engine import Engine

_HIDDEN_FIELD_TYPE = List[str]
_RELABELING_TYPE = Dict[str, str]


class ClickHouseConnectHook(BaseHook):
    """Hook for clickhouse database (using clickhouse-connect)."""

    conn_name_attr = ClickHouseHook.conn_name_attr
    default_conn_name = ClickHouseHook.default_conn_name
    conn_type = ClickHouseHook.conn_type
    hook_name = "ClickHouseConnect"  # Different name for distinction in the UI

    def __init__(
        self,
        clickhouse_conn_id: str = default_conn_name,
        database: Optional[str] = None,
        settings: Optional[Dict] = None,
        *args: Iterable[Any],
        **kwargs: Dict[str, Any],
    ) -> None:
        """
        Base constructor to create hook.

        :param clickhouse_conn_id: Airflow connection id
        :param database: if database not specified, then hook will use schema from connection
        :param settings: settings for clickhouse Client, can be none
        :param *args: additional arguments for parent constructor of BaseHook
        :param **kwargs: additional keyword arguments for parent constructor of BaseHook
        """
        super().__init__(*args, **kwargs)
        self.clickhouse_conn_id = clickhouse_conn_id
        self.database = database
        self.settings = settings

    def _ignored_argument_warning(self, arg_name: str) -> None:
        warnings.warn(
            f"The '{arg_name}' argument is currently not used and will be ignored in {self.hook_name}. "
            f"This behavior might change in future versions.",
            UserWarning
        )

    def get_conn(self) -> Client:
        """
        Retrieves the connection to ClickHouse using the provided connection ID.

        :return: ClickHouse Connect Client instance
        """
        connection: Connection = self.get_connection(
            getattr(self, self.conn_name_attr)
        )

        client = clickhouse_connect.get_client(
            host=connection.host,
            port=8123,
            username=connection.login,
            password=connection.password,
            database=self.database or connection.schema,
            settings=self.settings,
        )
        return client

    def run(
        self,
        sql: str,
        params: Optional[Dict[str, Any]] = None,
        settings: Optional[Dict[str, Any]] = None,
        query_id: Optional[str] = None,
        external_tables: Optional[List[Dict]] = None,
    ) -> Union[str, int, Sequence[str], QuerySummary]:
        """
        Client method that returns a single value instead of a result set

        :param sql: ClickHouse query/command as a python format string
        :param params: Optional dictionary of key/values pairs to be formatted
        :param settings: Optional dictionary of ClickHouse settings (key/string values)
        :param query_id: For backwards compatibility. Do nothing.
        :param external_tables: For backwards compatibility. Do nothing.

        :return: Decoded response from ClickHouse as either a string, int, or sequence of strings, or QuerySummary
        if no data returned
        """
        client = self.get_conn()
        self.log.info(f"Executing query: {sql}")

        if query_id is not None:
            self._ignored_argument_warning('query_id')

        if external_tables is not None:
            self._ignored_argument_warning('external_tables')

        try:
            result = client.command(
                sql, parameters=params, settings=settings
            )
            self.log.info("Query executed successfully.")
        finally:
            client.close()

        return result

    def insert_dataframe(
        self,
        table: str,
        dataframe: pd.DataFrame,
        settings: Optional[Dict[str, Any]] = None,
        query_id: Optional[str] = None,
        external_tables: Optional[List[Dict]] = None,
    ) -> int:
        """
        Insert a pandas DataFrame into ClickHouse.

        :param table: ClickHouse table
        :param dataframe: two-dimensional pandas dataframe
        :param settings: Optional dictionary of ClickHouse settings (key/string values)
        :param query_id: For backwards compatibility. Do nothing.
        :param external_tables: For backwards compatibility. Do nothing.

        :return: number of inserted rows, throws exception if insert fails
        """
        client = self.get_conn()
        self.log.info(f"Inserting into table {table} started.")

        if query_id is not None:
            self._ignored_argument_warning('query_id')

        if external_tables is not None:
            self._ignored_argument_warning('external_tables')

        try:
            result: QuerySummary = client.insert_df(
                table=table, df=dataframe, settings=settings
            )
            self.log.info("DataFrame inserted successfully.")
        finally:
            client.close()

        return result.written_rows

    def get_pandas_df(
        self,
        sql: str,
        params: Optional[Dict[str, Any]] = None,
        settings: Optional[Dict[str, Any]] = None,
        query_id: Optional[str] = None,
        external_tables: Optional[List[Dict]] = None,
    ) -> pd.DataFrame:
        """
        Query method that returns the results as a pandas dataframe.

        :param sql: Query statement
        :param params: Optional dictionary used to format the query
        :param settings: Optional dictionary of ClickHouse settings (key/string values)
        :param query_id: For backwards compatibility. Do nothing.
        :param external_tables: For backwards compatibility. Do nothing.

        :return: Pandas dataframe representing the result set
        """
        client = self.get_conn()
        self.log.info(f"Executing query: {sql}")

        if query_id is not None:
            self._ignored_argument_warning('query_id')

        if external_tables is not None:
            self._ignored_argument_warning('external_tables')

        try:
            result: pd.DataFrame = client.query_df(
                sql, settings=settings, parameters=params
            )
            self.log.info("Query executed successfully.")
        finally:
            client.close()

        return result

    def get_alchemy_engine(self) -> Engine:
        """
        Creates and returns a SQLAlchemy Engine instance for connecting to a ClickHouse database.

        :return: Engine: A SQLAlchemy Engine object to execute queries / interact with the ClickHouse database.
        """
        conn: Connection = self.get_connection(getattr(self, self.conn_name_attr))
        port = 8123
        schema = self.database or conn.schema

        uri: str = (
            f"clickhouse+connect://{conn.login}:{conn.password}@{conn.host}:{port}/{schema}"
        )
        self.log.info(uri)

        return create_engine(uri)

    @classmethod
    def get_ui_field_behaviour(cls) -> Dict[str, Union[_HIDDEN_FIELD_TYPE, _RELABELING_TYPE]]:
        """
        Defines the behavior of fields in the Airflow UI for connection forms.

        Returns:
            Dict[str, Union[_HIDDEN_FIELD_TYPE, _RELABELING_TYPE]]:
                - **hidden_fields** (List[str]): A list of field names to hide from the UI.
                  In this case, the `extra` field is hidden.
                - **relabeling** (Dict[str, str]): A dictionary mapping field names to
                  user-friendly labels. For example, the `schema` field is relabeled to `Database`.
        """
        return {
            "hidden_fields": ["extra"],
            "relabeling": {"schema": "Database"},
        }
