from airflow.models.baseoperator import BaseOperator
from airflow.models.dag import DAG
from airflow.policies import hookimpl
from airflow.exceptions import AirflowClusterPolicyViolation


@hookimpl
def task_policy(task: BaseOperator):
    use_kubernetes_if_config(task=task)


@hookimpl
def dag_policy(dag: DAG):
    """
    Ensure that DAG owner has the format 'team:name'
    """
    validate_owner_format(dag)


def use_kubernetes_if_config(task: BaseOperator):
    if task.executor_config:
        task.queue = 'kubernetes'


def validate_owner_format(dag: DAG):
    """
    Validate that the DAG owner follows the format 'team:name'
    Examples: team:recsys, team:dwh, team:growth
    """
    if not dag.owner:
        raise AirflowClusterPolicyViolation(
            f"DAG {dag.dag_id} has no owner. Owner is required."
        )
    
    if not isinstance(dag.owner, str):
        raise AirflowClusterPolicyViolation(
            f"DAG {dag.dag_id} owner should be a string. Current value: {dag.owner!r}"
        )
    
    if not dag.owner.startswith('team:'):
        raise AirflowClusterPolicyViolation(
            f"DAG {dag.dag_id} owner '{dag.owner}' does not follow the required format 'team:name'. "
            f"Examples: team:recsys, team:dwh, team:growth"
        )
