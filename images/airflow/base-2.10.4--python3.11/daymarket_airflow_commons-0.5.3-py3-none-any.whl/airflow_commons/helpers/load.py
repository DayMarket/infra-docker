import contextlib
from typing import Dict, Optional

import pandas
from airflow.providers.amazon.aws.hooks.s3 import S3Hook

from airflow_commons.logic.entities.s3 import S3Arguments
from airflow_commons.logic.load.s3 import S3PandasLoader


def load_s3(
    file_key: str,
    entity: pandas.DataFrame,
    pandas_kwargs: Dict[str, str] = None,
    bucket_name: Optional[str] = None,
    connection_id: Optional[str] = None,
) -> None:
    """
    Purpose is hide underlying implementation and provide simple API to load to S3.

    Args:
        file_key: full_path on s3 to upload pandas.DataFrame
        entity: loaded pandas.DataFrame
        pandas_kwargs: dict of pandas.(read_csv|read_parquet) method arguments - optional (default will be used)
        bucket_name: destination bucket name on s3 - optional (default will be used)
        connection_id: connection to use to interact with s3 - optional (default will be used)
    """
    hook = S3Hook(aws_conn_id=connection_id or 'airflow_bucket')

    with contextlib.closing(hook.get_conn()) as s3_connection:
        loader = S3PandasLoader(
            S3Arguments(
                bucket_name=bucket_name or hook.conn_config.extra_config['bucket_name'],
                file_key=file_key,
                pandas_kwargs=pandas_kwargs or {},
                s3_connection=s3_connection,
            ),
        )
        loader.load(entity)
