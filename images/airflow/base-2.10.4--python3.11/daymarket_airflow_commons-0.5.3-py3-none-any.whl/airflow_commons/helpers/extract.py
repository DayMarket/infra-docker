import contextlib
from typing import Dict, Optional

import pandas
from airflow.providers.amazon.aws.hooks.s3 import S3Hook

from airflow_commons.logic.entities.s3 import S3Arguments
from airflow_commons.logic.extract.s3 import S3PandasExtractor


def extract_s3(
    file_key: str,
    connection_id: Optional[str] = None,
    bucket_name: Optional[str] = None,
    pandas_kwargs: Optional[Dict[str, str]] = None,
) -> pandas.DataFrame:
    """
    Purpose is hide underlying implementation and provide simple API to read from S3.

    Args:
        file_key: full_path to the object on s3
        connection_id: connection to use to interact with s3 - optional (default will be used)
        bucket_name: source bucket name on s3 - optional (default will be used)
        pandas_kwargs: dict of pandas.(read_csv|read_parquet) method arguments - optional (default will be used)

    Returns:
        object converted to pandas.DataFrame
    """
    hook = S3Hook(aws_conn_id=connection_id or 'airflow_bucket')

    with contextlib.closing(hook.get_conn()) as s3_connection:
        extractor = S3PandasExtractor(
            S3Arguments(
                bucket_name=bucket_name or hook.conn_config.extra_config['bucket_name'],
                file_key=file_key,
                pandas_kwargs=pandas_kwargs or {},
                s3_connection=s3_connection,
            ),
        )
        return extractor.extract()
