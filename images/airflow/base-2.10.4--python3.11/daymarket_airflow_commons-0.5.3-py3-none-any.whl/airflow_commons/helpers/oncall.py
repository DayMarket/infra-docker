import json
import logging
from functools import cached_property
from typing import Any

from airflow.models import Variable
from airflow.notifications.basenotifier import BaseNotifier
from airflow.providers.http.hooks.http import HttpHook
from airflow.hooks.base import BaseHook


class GrafanaOnCallNotifier(BaseNotifier):
    """
    Grafana OnCall Notifier optimized for daymarket.uz instance.

    :param message: Alert message (supports templating)
    :param severity: P1 (highest) to P3 (lowest), defaults to P3
    :param source: System source identifier (default: airflow)
    :param action: trigger/resolve/acknowledge (default: trigger)
    :param dedup_key: Deduplication identifier (auto-generated if None)
    :param custom_details: Additional context as dict
    :param component: Affected component
    :param alert_type: Classification of alert
    :param links: List of relevant links
    :param webhook_path: The path part of webhook URL after '/integrations/v1/webhook/'
    """

    template_fields = (
        "message",
        "severity",
        "source",
        "action",
        "dedup_key",
        "custom_details",
        "component",
        "alert_type",
        "links",
    )

    def __init__(
        self,
        *,
        message: str = "Airflow DAG {{ dag.dag_id }} failed",
        severity: str = "P3",
        source: str = "airflow",
        action: str = "trigger",
        team: str = "dwh",
        dedup_key: str | None = None,
        custom_details: Any | None = None,
        component: str | None = None,
        alert_type: str | None = "DAG failure",
        links: list[Any] | None = None,
        oncall_webhook_conn_id: str = "oncall_webhook_default",
    ):
        super().__init__()
        self.message = message
        self.severity = severity if severity in ["P1", "P2", "P3", "P4", "P5"] else "P3"
        self.source = source
        self.action = action
        self.team = team
        self.dedup_key = dedup_key
        self.custom_details = custom_details
        self.component = component
        self.alert_type = alert_type
        self.links = links
        self.oncall_webhook_conn_id = oncall_webhook_conn_id

    @cached_property
    def hook(self) -> HttpHook:
        """Configured HTTP Hook for OnCall."""
        return HttpHook(
            method="POST",
            http_conn_id=self.oncall_webhook_conn_id,
        )

    def _build_payload(self, context: dict) -> dict:
        """Construct OnCall-compatible payload with Airflow context."""
        dag = context.get("dag")
        task = context.get("task")

        # Auto-generate dedup_key if not provided
        alias = self.dedup_key or (
            f"airflow:{dag.dag_id}:{task.task_id}:{context.get('execution_date').isoformat()}"
            if dag and task and context.get("execution_date")
            else f"airflow:{context.get('ts_nodash')}"
        )

        payload = {
            "message": self.message,
            "alias": alias,
            "description": f"Airflow task failure in {dag.dag_id if dag else 'unknown'}",
            "severity": self.severity,
            "tags": [self.source, "airflow", self.component]
            if self.component
            else [self.source, "airflow"],
            "team": self.team,
            "extra_properties": {
                "custom_details": self.custom_details or {},
                "component": self.component,
                "alert_type": self.alert_type,
                "airflow_context": {
                    "dag_id": dag.dag_id if dag else None,
                    "task_id": task.task_id if task else None,
                    "logical_date": context.get("logical_date").isoformat()
                    if context.get("logical_date")
                    else None,
                    "try_number": context.get("ti").try_number
                    if context.get("ti")
                    else None,
                },
            },
        }

        # Add task log link if available
        if context.get("ti"):
            payload["link"] = context["ti"].log_url

        return payload

    def notify(self, context: dict, force_send: bool = False) -> None:
        """Send alert to OnCall webhook."""
        if not force_send and Variable.get("env", default_var="dev") != "prod":
            logging.info("Skipping OnCall notification in non-production environment")
            return

        payload = self._build_payload(context)
        endpoint = BaseHook.get_connection(
            self.oncall_webhook_conn_id
        ).extra_dejson.get("endpoint")

        if not endpoint:
            raise ValueError("Endpoint is not set for OnCall webhook")

        try:
            self.hook.run(
                endpoint=endpoint,
                data=json.dumps(payload),
                headers={"Content-Type": "application/json"},
                extra_options={"timeout": 5},
            )
            logging.info(f"Sent alert to OnCall: {payload.get('message')}")
        except Exception as e:
            logging.error(f"Failed to send OnCall notification: {str(e)}")
            raise


send_oncall_notification = GrafanaOnCallNotifier