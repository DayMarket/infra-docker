from airflow_dag_generator.macro.hooks import HookManager


class MacroManager:

    macro_mapping = {
        'hook': HookManager.hook,
    }

    @classmethod
    def add_macro(cls, name, macro):
        """
        Add macro(function) to index.

        Args:
            name: name of macro
            macro: python executable
        """
        cls.macro_mapping[name] = macro

    @classmethod
    def execute(cls, macro: str):
        """
        Execute macro using local scope of functions.

        Args:
            macro: string of python code

        Returns:
            Any: any object from macro
        """
        return eval(macro, cls.macro_mapping)  # noqa: WPS421, S307
