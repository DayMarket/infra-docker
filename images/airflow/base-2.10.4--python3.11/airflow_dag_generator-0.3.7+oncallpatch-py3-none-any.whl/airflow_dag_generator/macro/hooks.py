from airflow.providers.postgres.hooks.postgres import PostgresHook


class HookManager:
    hook_mapping = {
        'postgres': PostgresHook,
    }

    @classmethod
    def add_hook_mapping(cls, hook_type, hook_class):
        cls.hook_mapping[hook_type] = hook_class

    @classmethod
    def hook(cls, hook_type, **kwargs):
        return cls.hook_mapping[hook_type](**kwargs)
