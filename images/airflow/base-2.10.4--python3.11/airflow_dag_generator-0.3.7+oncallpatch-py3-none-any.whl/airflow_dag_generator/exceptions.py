
class TaskTypeResolvingError(Exception):

    def __init__(self, task_type: str):
        super().__init__(
            'The task of type "{task_type}" could not be found.'.format(task_type=task_type),
        )


class TooManyDagsError(Exception):

    def __init__(self, dag_ids):
        super().__init__(
            'Please ensure that you specify only one DAG per file. The following DAG IDs were provided: {dag_ids}.'.
            format(dag_ids=', '.join(dag_ids)),
        )


class DifferentTasksAndFlowError(Exception):

    def __init__(self, tasks, flow):
        missed_flow = tasks - flow
        missed_tasks = flow - tasks
        super().__init__(
            'The flow and tasks should align, but there are missed tasks({missed_tasks}) or flow({missed_flow})'.
            format(
                missed_tasks=', '.join(missed_tasks),
                missed_flow=', '.join(missed_flow),
            ),
        )


class MissingFlowSpecError(Exception):

    def __init__(self):
        super().__init__(
            'Missing required "flow" field in dag config',
        )


class MissingTasksSpecError(Exception):

    def __init__(self):
        super().__init__(
            'Missing required "tasks" field in dag config',
        )
