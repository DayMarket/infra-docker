# flake8: noqa N805

from typing import Any, Mapping, Optional

from pydantic import validator

from airflow_dag_generator import __path__
from airflow_dag_generator.macro import MacroManager
from airflow_dag_generator.schema.base import Base

with open('{airflow_dag_generator}/res/task_md.template.md'.format(airflow_dag_generator=__path__[0])) as task_md_f:
    TASK_MD_TEMPLATE = task_md_f.read()


class Task(Base):
    type: str
    description: Optional[str]
    kwargs: Optional[Mapping[str, Any]]

    class Config:
        """Pydantic Config nested class."""

        validate_assignment = True

    def __str__(self):
        """
        Make string represention of task config in markdown format.

        Returns:
            str: markdown represention of task
        """
        return TASK_MD_TEMPLATE.format(
            type=self.type,
            description=self.description,
        )

    @validator('kwargs', pre=True, always=True)
    def kwargs_validator(cls, kwargs):
        """
        Validator for handling macro injections in string values.

        Args:
            kwargs: dict of kwargs

        Returns:
            dict: updated kwargs
        """
        for field_key, field_value in kwargs.items():
            if isinstance(field_value, dict):
                if field_value.get('from_macro'):
                    kwargs[field_key] = MacroManager.execute(field_value['from_macro'])
        return kwargs
