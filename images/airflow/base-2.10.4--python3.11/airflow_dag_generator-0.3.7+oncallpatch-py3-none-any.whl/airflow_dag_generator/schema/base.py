# flake8: noqa N805

from typing import Any, Dict

from pydantic import BaseModel, root_validator


class Base(BaseModel):

    class Config:
        """Pydantic Config nested class."""

        validate_assignment = True

    @root_validator(pre=True)
    def build_extra(csl, model_values):
        """
        Root validator to handle extra fields.

        Set extra fileds to kwargs dict.

        Args:
            model_values: set of values used during instance initialization.

        Returns:
            Dict[str, Any]: updated model values

        """
        all_required_field_names = {
            field.alias
            for field in csl.__fields__.values()
            if field.alias != 'kwargs'
        }

        extra: Dict[str, Any] = {}
        for field_name in list(model_values):
            if field_name not in all_required_field_names:
                extra[field_name] = model_values.pop(field_name)
        model_values['kwargs'] = extra
        return model_values
