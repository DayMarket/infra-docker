# flake8: noqa N805

from typing import List, Optional

from pydantic import validator

from airflow_dag_generator.schema.base import Base


class TaskFlow(Base):
    depends_on: Optional[List[str]]

    class Config:
        """Pydantic Config nested class."""

        validate_assignment = True

    @validator('depends_on', pre=True, always=True)
    def depends_on_validator(cls, depends_on):
        """
        Validator of replacing None object with empty list for depends_on.

        Args:
            depends_on:  Optional[List] of depends_on

        Returns:
            List: list of depends_on
        """
        return depends_on or []
