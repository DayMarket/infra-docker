# flake8: noqa N805

from __future__ import annotations

import datetime
from typing import Any, Dict, List, Optional, Union

import pendulum
from pydantic import root_validator, validator

from airflow_dag_generator import __path__
from airflow_dag_generator.exceptions import DifferentTasksAndFlowError, MissingFlowSpecError, MissingTasksSpecError
from airflow_dag_generator.schema.base import Base
from airflow_dag_generator.schema.task import Task
from airflow_dag_generator.schema.task_flow import TaskFlow

from airflow_commons.helpers.notify import send_alert_to_slack
from airflow_commons.helpers.oncall import send_oncall_notification

with open('{airflow_dag_generator}/res/doc_md.template.md'.format(airflow_dag_generator=__path__[0])) as doc_md_f:
    DOC_MD_TEMPLATE = doc_md_f.read()


class DAG(Base):
    """Pydantic model for DAG config."""

    config_dir: str
    dag_id: str
    tags: List[str]
    owner: Optional[str]
    description: Optional[str]
    start_date: datetime.datetime
    kwargs: Optional[Dict[str, Any]]

    tasks: Dict[str, Task]
    flow: Any  # Union[Dict[str, TaskFlow], List[str]]

    def __str__(self):
        """
        Make string represention of dag config in markdown format.

        Returns:
            str: markdown represention of dag
        """
        return DOC_MD_TEMPLATE.format(
            dag_id=self.dag_id,
            description=self.description,
            owner=self.owner,
            tasks=self._tasks_md(),
        )

    @validator('start_date', pre=True, always=True)
    def start_date_validator(cls, start_date: str):
        """
        Validator for parsing str start_date as a datetime.

        Args:
            start_date: string representation of start_date

        Returns:
            datetime.datetime: datetime object
        """
        return pendulum.parse(start_date)

    @validator('tags', pre=True, always=True)
    def tags_validator(cls, tags: Optional[List[str]]) -> List[str]:
        """
        Validator of replacing None object with empty list for tags.

        Args:
            tags:  Optional[List] of tags

        Returns:
            List: list of tags
        """
        return tags or []

    @validator('flow', pre=True, always=True)
    def flow_validator(cls, flow: Union[Dict[str, Any] | List[str]]) -> Dict[str, TaskFlow]:
        """
        There are type types of flow are available.

        This validator converts List type of description to Dict.

        Args:
              flow: Dict[str, TaskFlow] or List[str]  description of flow

        Returns:
            Dict[str, TaskFlow]: Dict description of flow
        """
        if isinstance(flow, List):
            result = {}
            depends_on = None
            for node in flow:
                result[node] = TaskFlow(depends_on=depends_on)
                depends_on = [node]
            return result
        flow = {
            node: TaskFlow(
                depends_on=node_spec.get('depends_on', []),
            )
            for node, node_spec in flow.items()
        }
        return flow

    @root_validator(pre=True)
    def dag_root_validator(cls, model_values):
        if 'flow' not in model_values:
            raise MissingFlowSpecError
        if 'tasks' not in model_values:
            raise MissingTasksSpecError
        elif isinstance(model_values['flow'], list):
            flow = set(model_values['flow'])
        else:
            flow = set(model_values['flow'].keys())
        tasks = set(model_values['tasks'].keys())
        if flow != tasks:
            raise DifferentTasksAndFlowError(flow=flow, tasks=tasks)
        return model_values

    def _tasks_md(self):
        return ''.join(
            ' - {task_id}: {task_md}'.format(
                task_id=task_id,
                task_md=task_md,
            )
            for task_id, task_md in self.tasks.items()
        )

    @validator('kwargs', pre=True, always=True)
    def kwargs_validator(cls, kwargs: Optional[Dict[str, Any]], values) -> Dict[str, Any]:
        """
        If alerts is not specified or it's True, we want to use default method for alerting from airflow-commons
        Args:
              kwargs: dict of not required arguments of dag
              values: dict of all model values for accessing owner field

        Returns:
            Dict[str, Any]: Dict with arguments of dag
        """
        def _set_on_failure_callback(alerts):
            # Extract team name from owner (format: "team:some_team")
            # Check owner in main values first, then in default_args, then use default
            default_args = kwargs.get('default_args', {})
            owner_value = default_args.get('owner') or 'team:default'

            parts = owner_value.split(':')
            team = parts[1] if len(parts) > 1 else 'default'
            oncall_webhook_conn_id = f'oncall_webhook_{team}'
            
            available_callbacks = {
                'slack': send_alert_to_slack,
                'oncall': send_oncall_notification(oncall_webhook_conn_id=oncall_webhook_conn_id)
            }
            if isinstance(alerts, list):
                callbacks = []
                for alert in alerts:
                    callbacks.append(available_callbacks[alert])
                kwargs['on_failure_callback'] = callbacks
            elif isinstance(alerts, str):
                kwargs['on_failure_callback'] = available_callbacks[alerts]
            elif alerts is None or alerts is True:
                kwargs['on_failure_callback'] = available_callbacks['slack']

        kwargs = kwargs or {}
        _set_on_failure_callback(kwargs.get('alerts'))
        kwargs.pop('alerts', None)

        return kwargs
