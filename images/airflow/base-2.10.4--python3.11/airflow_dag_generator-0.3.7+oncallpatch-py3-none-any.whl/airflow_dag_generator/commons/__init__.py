# flake8: noqa F401

from airflow.operators.latest_only import LatestOnlyOperator
from airflow.operators.trigger_dagrun import TriggerDagRunOperator

from airflow_dag_generator import TaskManager
from airflow_dag_generator.commons.generate_dags import generate_dags
from airflow_dag_generator.commons.handlers import (
    ClickhouseExecuteOperatorHandler,
    ClickhouseDeleteOperatorHandler,
    ExternalTaskSensorHandler,
    FileToClickhouseOperatorHandler,
    PostgresToClickhouseOperatorHandler,
    SQLToFileOperatorHandler,
    SparkSqlOperatorHandler,
    ClickhouseToClickhouseOperatorHandler,
)

TaskManager.add_task_mapping('clickhouse_execute', ClickhouseExecuteOperatorHandler)
TaskManager.add_task_mapping('clickhouse_delete', ClickhouseDeleteOperatorHandler)
TaskManager.add_task_mapping('postgres_to_clickhouse', PostgresToClickhouseOperatorHandler)
TaskManager.add_task_mapping('sql_to_file', SQLToFileOperatorHandler)
TaskManager.add_task_mapping('file_to_clickhouse', FileToClickhouseOperatorHandler)
TaskManager.add_task_mapping('latest_only', LatestOnlyOperator)
TaskManager.add_task_mapping('external_task_sensor', ExternalTaskSensorHandler)
TaskManager.add_task_mapping('trigger_dagrun', TriggerDagRunOperator)
TaskManager.add_task_mapping('spark_sql', SparkSqlOperatorHandler)
TaskManager.add_task_mapping('clickhouse_to_clickhouse', ClickhouseToClickhouseOperatorHandler)
