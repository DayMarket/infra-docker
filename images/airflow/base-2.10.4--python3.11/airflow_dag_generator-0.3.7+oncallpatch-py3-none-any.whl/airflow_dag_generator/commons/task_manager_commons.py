from typing import Optional

from airflow_dag_generator.schema import Task
from airflow_dag_generator.task_manager import TaskManager


class TaskManagerCommons(TaskManager):

    def __init__(self, owner_default_params_mapping):
        self.owner_default_params_mapping = owner_default_params_mapping

    def generate_task(self, task_id: str, task_spec: Task, owner: Optional[str] = None):
        default_params = self.owner_default_params_mapping.get(owner, {}).get(task_spec.type, {})
        task_spec.kwargs = default_params | task_spec.kwargs
        return super().generate_task(task_id, task_spec)
