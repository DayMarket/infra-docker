import argparse

from airflow_dag_generator.commons.generate_dags import validate_dags


def cli():
    parser = argparse.ArgumentParser()

    parser.add_argument(
        '--configs_path',
        action='store',
        help='Path to folder with dags',
        required=True,
    )

    parser.add_argument(
        '--owner_default_params_mapping',
        action='store',
        help='Path to owner_default_params_mapping config',
        required=True,
    )

    args = parser.parse_args()

    return validate_dags(
        args.configs_path,
        args.owner_default_params_mapping,
    )
