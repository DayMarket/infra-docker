import logging
import os

from airflow_dag_generator import DAGGenerator
from airflow_dag_generator.commons.config_parser_commons import ConfigParserCommons
from airflow_dag_generator.commons.dag_graph_builder_commons import DAGGraphBuilderCommons
from airflow_dag_generator.commons.task_manager_commons import TaskManagerCommons

logger = logging.getLogger(__name__)


def walk_files_recursively(root_dir_path):
    for dir_path, _, files in os.walk(root_dir_path):
        for file_name in files:
            file_path = os.path.join(dir_path, file_name)
            yield file_path


def generate_dags(configs_dir, owner_default_params_mapping):
    config_parser = ConfigParserCommons()
    task_manager = TaskManagerCommons(config_parser.read_config(owner_default_params_mapping))
    dag_graph_builder = DAGGraphBuilderCommons(task_manager=task_manager)
    dag_generator = DAGGenerator(config_parser=config_parser, dag_graph_builder=dag_graph_builder)

    for config_file in walk_files_recursively(configs_dir):
        if not config_file.endswith('.yaml'):
            continue
        try:
            yield dag_generator.generate(config_file)
        except Exception:  # noqa: S110
            # We aim to prevent the failure of all DAGs due to an error in a single DAG.
            pass  # noqa: WPS420


def validate_dags(configs_dir, owner_default_params_mapping):
    result_code = 0
    invalid_configs = []

    config_parser = ConfigParserCommons()
    task_manager = TaskManagerCommons(config_parser.read_config(owner_default_params_mapping))
    dag_graph_builder = DAGGraphBuilderCommons(task_manager=task_manager)
    dag_generator = DAGGenerator(config_parser=config_parser, dag_graph_builder=dag_graph_builder)

    for config_file in walk_files_recursively(configs_dir):
        if not config_file.endswith('.yaml'):
            continue
        if not dag_generator.validate(config_file):
            result_code = 1
            invalid_configs.append(config_file)
    if result_code:
        invalid_configs_str = '\n - '.join(invalid_configs)
        logger.error('Errors in following configs:\n - {invalid_configs_str}'.format(
            invalid_configs_str=invalid_configs_str,
        ))
    return result_code
