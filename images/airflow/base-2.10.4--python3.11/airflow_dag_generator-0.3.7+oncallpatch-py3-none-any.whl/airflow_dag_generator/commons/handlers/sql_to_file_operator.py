# flake8: noqa

from typing import Dict, Optional

from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow_commons.hooks.clickhouse_hook import ClickHouseHook
from airflow_commons.hooks.clickhouse_connect_hook import ClickHouseConnectHook
from airflow_commons.operators.sql_to_file_operator import SQLToFileOperator


class SQLToFileOperatorHandler(SQLToFileOperator):

    def __init__(
            self,
            sql: str,
            filename: str,
            postgresql_conn: Optional[str] = '',
            clickhouse_conn: Optional[str] = '',
            filepath: Optional[str] = '/opt/airflow/s3fs/{{ dag.dag_id }}/{{ run_id }}',
            pd_to_csv_kwargs: Optional[Dict[str, str]] = None,
            pd_to_parquet_kwargs: Optional[Dict[str, str]] = None,
            use_ch_connect: Optional[bool] = False,
            *args,
            **kwargs,
    ):
        if postgresql_conn:
            db_hook = PostgresHook(postgres_conn_id=postgresql_conn)
        elif clickhouse_conn and use_ch_connect:
            db_hook = ClickHouseConnectHook(clickhouse_conn_id=clickhouse_conn)
        elif clickhouse_conn and (not use_ch_connect):
            db_hook = ClickHouseHook(clickhouse_conn_id=clickhouse_conn)
        else:
            raise KeyError('You should specify "postgresql_conn" or "clickhouse_conn"')

        super().__init__(
            sql=sql,
            filename=filename,
            db_hook=db_hook,
            filepath=filepath,
            pd_to_csv_kwargs=pd_to_csv_kwargs,
            pd_to_parquet_kwargs=pd_to_parquet_kwargs,
            *args,
            **kwargs
        )

