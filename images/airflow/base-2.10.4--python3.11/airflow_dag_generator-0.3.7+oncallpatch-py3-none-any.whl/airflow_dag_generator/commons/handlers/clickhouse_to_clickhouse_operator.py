from collections import namedtuple
from typing import List, Optional, Tuple

from airflow_commons.operators.clickhouse_to_clickhouse_operator import ClickhouseToClickhouseOperator

TablePartition = namedtuple('TablePartition', 'table partition')


class ClickhouseToClickhouseOperatorHandler(ClickhouseToClickhouseOperator):

    def __init__(
            self,
            *,
            sql: str,
            clickhouse_source_conn_name: str,
            clickhouse_dest_conn_name: str,
            clickhouse_dest_schema: str,
            clickhouse_dest_table: str,
            column_list: Tuple = ('*',),
            truncate: Optional[bool] = False,
            partitions_to_optimize: Optional[List[TablePartition]] = None,
            **kwargs,
    ):

        super().__init__(
            sql=sql,
            clickhouse_source_conn_name=clickhouse_source_conn_name,
            clickhouse_dest_conn_name=clickhouse_dest_conn_name,
            clickhouse_dest_schema=clickhouse_dest_schema,
            clickhouse_dest_table=clickhouse_dest_table,
            column_list=column_list,
            truncate=truncate,
            partitions_to_optimize=partitions_to_optimize,
            **kwargs,
        )
