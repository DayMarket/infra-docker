# flake8: noqa

from collections import namedtuple
from typing import Dict, List, Optional, Union

from airflow_commons.hooks.clickhouse_hook import ClickHouseHook
from airflow_commons.hooks.clickhouse_connect_hook import ClickHouseConnectHook
from airflow_commons.operators.clickhouse_execute_operator import ClickhouseExecuteOperator

TablePartition = namedtuple('TablePartition', 'table partition')


class ClickhouseExecuteOperatorHandler(ClickhouseExecuteOperator):

    def __init__(self,
                 *,
                 sql: str,
                 connection: str,
                 query_id: Optional[str] = None,
                 partitions_to_optimize: Optional[List[TablePartition]] = None,
                 external_tables: Optional[List[Dict]] = None,
                 use_ch_connect: Optional[bool] = False,
                 hook_settings: Optional[Dict[str, Union[str, int, float, bool]]] = None,
                 **kwargs):
        settings: Optional[Dict[str, Union[str, int, float, bool]]] = {'allow_experimental_lightweight_delete': 1}
        if hook_settings:
            settings.update(hook_settings)  # Overwrite defaults with passed settings

        if use_ch_connect:
            ch_hook = ClickHouseConnectHook(clickhouse_conn_id=connection, settings=settings)
        else:
            ch_hook = ClickHouseHook(clickhouse_conn_id=connection, settings=settings)

        super().__init__(
            sql=sql,
            ch_hook=ch_hook,
            query_id=query_id,
            partitions_to_optimize=partitions_to_optimize,
            external_tables=external_tables,
            **kwargs
        )
