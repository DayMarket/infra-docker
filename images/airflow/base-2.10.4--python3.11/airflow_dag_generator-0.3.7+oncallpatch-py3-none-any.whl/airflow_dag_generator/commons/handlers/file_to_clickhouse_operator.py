# flake8: noqa

from collections import namedtuple
from typing import Callable, Dict, List, Optional, Tuple

import pandas as pd
from airflow.utils.context import Context
from airflow_commons.hooks.clickhouse_hook import ClickHouseHook
from airflow_commons.hooks.clickhouse_connect_hook import ClickHouseConnectHook
from airflow_commons.operators.file_to_clickhouse_operator import FileToClickhouseOperator

TablePartition = namedtuple("TablePartition", "table partition")


class FileToClickhouseOperatorHandler(FileToClickhouseOperator):

    def __init__(self,
                 connection: str,
                 target_table: str,
                 filename: str,
                 filepath: str = "/opt/airflow/s3fs/{{ dag.dag_id }}/{{ run_id }}",
                 column_list: Tuple = ("*",),
                 truncate: bool = False,
                 query_id: Optional[str] = None,
                 external_tables: Optional[List[Dict]] = None,
                 partitions_to_optimize: Optional[List[TablePartition]] = None,
                 pd_read_csv_kwargs: Optional[Dict[str, str]] = None,
                 pd_read_parquet_kwargs: Optional[Dict[str, str]] = None,
                 use_ch_connect: Optional[bool] = False,
                 *args,
                 **kwargs,
                 ):
        if use_ch_connect:
            ch_hook = ClickHouseConnectHook(clickhouse_conn_id=connection)
        else:
            ch_hook = ClickHouseHook(clickhouse_conn_id=connection)

        super().__init__(
            ch_hook=ch_hook,
            target_table=target_table,
            filename=filename,
            filepath=filepath,
            column_list=column_list,
            truncate=truncate,
            query_id=query_id,
            external_tables=external_tables,
            partitions_to_optimize=partitions_to_optimize,
            pd_read_csv_kwargs=pd_read_csv_kwargs,
            pd_read_parquet_kwargs=pd_read_parquet_kwargs,
            *args,
            **kwargs,
        )
