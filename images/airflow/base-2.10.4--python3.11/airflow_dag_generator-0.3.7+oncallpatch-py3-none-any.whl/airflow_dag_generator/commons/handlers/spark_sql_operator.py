from airflow_commons.operators.spark_sql_operator import SparkSqlOperator


class SparkSqlOperatorHandler(SparkSqlOperator):
    def __init__(
        self,
        *,
        sql: str,
        spark_repartition: int = 200,
        spark_resources_setting: str = '',
        hudi_output_path: str = '',
        hudi_hive_target_db: str = '',
        hudi_hive_target_table: str = '',
        hudi_key_columns: str = '',
        hudi_write_mode: str = '',
        hudi_options: str = '',
        clickhouse_target_table: str = '',
        clickhouse_write_batch_size: int = 10000,
        clickhouse_conn: str = '',
        s3_output_path: str = '',
        s3_output_format: str = '',
        **kwargs,
    ):
        super().__init__(
            sql=sql,
            spark_repartition=spark_repartition,
            spark_resources_setting=spark_resources_setting,
            hudi_output_path=hudi_output_path,
            hudi_hive_target_db=hudi_hive_target_db,
            hudi_hive_target_table=hudi_hive_target_table,
            hudi_key_columns=hudi_key_columns,
            hudi_write_mode=hudi_write_mode,
            hudi_options=hudi_options,
            clickhouse_target_table=clickhouse_target_table,
            clickhouse_write_batch_size=clickhouse_write_batch_size,
            clickhouse_conn_id=clickhouse_conn,
            s3_output_path=s3_output_path,
            s3_output_format=s3_output_format,
            **kwargs,
        )
