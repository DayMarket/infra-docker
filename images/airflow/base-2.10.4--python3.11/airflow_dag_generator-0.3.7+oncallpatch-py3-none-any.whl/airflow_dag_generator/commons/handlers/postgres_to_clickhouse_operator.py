# flake8: noqa

from collections import namedtuple
from typing import Dict, List, Optional, Tuple

from airflow.providers.postgres.hooks.postgres import PostgresHook
from airflow_commons.hooks.clickhouse_hook import ClickHouseHook
from airflow_commons.hooks.clickhouse_connect_hook import ClickHouseConnectHook
from airflow_commons.operators.postgres_to_clickhouse_operator import PostgresToClickhouseOperator

TablePartition = namedtuple('TablePartition', 'table partition')


class PostgresToClickhouseOperatorHandler(PostgresToClickhouseOperator):

    def __init__(
            self,
            *,
            sql: str,
            postgresql_conn: str,
            clickhouse_conn: str,
            clickhouse_table: str,
            column_list: Tuple = ('*',),
            truncate: Optional[bool] = False,
            query_id: Optional[str] = None,
            external_tables: Optional[List[Dict]] = None,
            partitions_to_optimize: Optional[List[TablePartition]] = None,
            use_ch_connect: Optional[bool] = False,
            **kwargs,
    ):
        postgresql_hook = PostgresHook(postgres_conn_id=postgresql_conn)

        if use_ch_connect:
            clickhouse_hook = ClickHouseConnectHook(clickhouse_conn_id=clickhouse_conn)
        else:
            clickhouse_hook = ClickHouseHook(clickhouse_conn_id=clickhouse_conn)

        super().__init__(
            sql=sql,
            postgresql_hook=postgresql_hook,
            clickhouse_hook=clickhouse_hook,
            clickhouse_table=clickhouse_table,
            column_list=column_list,
            truncate=truncate,
            query_id=query_id,
            external_tables=external_tables,
            partitions_to_optimize=partitions_to_optimize,
            **kwargs,
        )



