# flake8: noqa

from typing import Dict, Optional, Union

from airflow_commons.hooks.clickhouse_connect_hook import ClickHouseConnectHook
from airflow_commons.operators.clickhouse_delete_operator import ClickhouseDeleteOperator


class ClickhouseDeleteOperatorHandler(ClickhouseDeleteOperator):

    def __init__(self,
                 *,
                 table_name: str,
                 where: str,
                 connection: str,
                 in_partition: Optional[str] = None,
                 hook_settings: Optional[Dict[str, Union[str, int, float, bool]]] = None,
                 **kwargs):
        settings: Optional[Dict[str, Union[str, int, float, bool]]] = {'allow_experimental_lightweight_delete': 1}
        if hook_settings:
            settings.update(hook_settings)  # Overwrite defaults with passed settings

        ch_hook = ClickHouseConnectHook(clickhouse_conn_id=connection, settings=settings)

        super().__init__(
            table_name=table_name,
            where=where,
            in_partition=in_partition,
            ch_hook=ch_hook,
            **kwargs
        )