# flake8: noqa: WPS211

from datetime import timedelta
from typing import Collection, Iterable, Optional

from airflow.sensors.external_task import ExternalTaskSensor


class ExternalTaskSensorHandler(ExternalTaskSensor):

    def __init__(
            self,
            *,
            external_dag_id: str,
            external_task_id: Optional[str] = None,
            external_task_ids: Optional[Collection[str]] = None,
            allowed_states: Optional[Iterable[str]] = None,
            failed_states: Optional[Iterable[str]] = None,
            execution_delta_second: Optional[float] = None,
            check_existence: bool = False,
            **kwargs,
    ):
        execution_delta = timedelta(seconds=execution_delta_second) if execution_delta_second else None
        super().__init__(
            external_dag_id=external_dag_id,
            external_task_id=external_task_id,
            external_task_ids=external_task_ids,
            allowed_states=allowed_states,
            failed_states=failed_states,
            execution_delta=execution_delta,
            check_existence=check_existence,
            **kwargs,
        )
