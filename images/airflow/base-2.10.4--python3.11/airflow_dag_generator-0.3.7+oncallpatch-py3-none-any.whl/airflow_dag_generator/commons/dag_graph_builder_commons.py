from airflow_dag_generator.dag_graph_builder import DAGGraphBuilder
from airflow_dag_generator.schema import DAG


class DAGGraphBuilderCommons(DAGGraphBuilder):

    def _tasks_mapping(self, user_dag: DAG):
        return {
            task_id: self.task_manager.generate_task(task_id, task, user_dag.owner)
            for task_id, task in user_dag.tasks.items()
        }
