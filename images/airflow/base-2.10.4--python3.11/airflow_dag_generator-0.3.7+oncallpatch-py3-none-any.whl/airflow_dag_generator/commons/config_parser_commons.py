import os

from airflow_dag_generator.config_parser import ConfigParser
from airflow_dag_generator.exceptions import TooManyDagsError
from airflow_dag_generator.schema import DAG


class ConfigParserCommons(ConfigParser):

    def parse_config(self, path: str) -> DAG:
        """
        Read yaml config from file and return pydantic entities.

        Only one root object should be placed.

        Args:
            path: path to yaml file

        Returns:
            pydantic model for DAG

        Raises:
            TooManyDagsError: if more than root object in yaml file
        """
        dag_config = self.read_config(path)

        if len(dag_config.items()) != 1:
            raise TooManyDagsError(dag_config.keys())
        owner = self._extract_owner(path)
        config_dir = os.path.dirname(path)
        dag_id, dag_config = next(iter(dag_config.items()))
        dag_config['owner'] = owner
        return DAG(dag_id=dag_id, config_dir=config_dir, **dag_config)

    def _extract_owner(self, config_path: str):
        """
        Getting owner based on config path.

        Args:
            config_path: path to config file

        Returns:
            str: name of latest directory
        """
        path = os.path.normpath(config_path)
        dirs = os.path.dirname(path).split(os.sep)
        return dirs[-1] if dirs else None
