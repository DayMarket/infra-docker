import os
from typing import Any, Dict

from ruamel.yaml import YAML

from airflow_dag_generator.exceptions import TooManyDagsError
from airflow_dag_generator.schema import DAG


class ConfigParser:

    def read_config(self, path: str) -> Dict[str, Any]:
        """
        Read yaml file and return dict representation.

        Args:
            path: path to yaml file

        Returns:
            dict represantation of yaml file
        """
        with open(path, 'r') as config_file:
            file_content = config_file.read()
            yaml = YAML(typ='safe').load(file_content)

        return yaml

    def parse_config(self, path: str) -> DAG:
        """
        Read yaml config from file and return pydantic entities.

        Only one root object should be placed

        Args:
            path: path to yaml file

        Returns:
            pydantic model for DAG

        Raises:
            TooManyDagsError: if more than root object in yaml file
        """
        dag_config = self.read_config(path)

        if len(dag_config.items()) != 1:
            raise TooManyDagsError(dag_config.keys())

        config_dir = os.path.dirname(path)
        dag_id, dag_config = next(iter(dag_config.items()))
        return DAG(dag_id=dag_id, config_dir=config_dir, **dag_config)
