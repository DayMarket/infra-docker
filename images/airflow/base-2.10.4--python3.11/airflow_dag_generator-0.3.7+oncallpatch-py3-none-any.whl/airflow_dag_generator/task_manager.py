from airflow.decorators.base import _TaskDecorator  # noqa: WPS450
from airflow.operators.bash import BashOperator

from airflow_dag_generator.exceptions import TaskTypeResolvingError
from airflow_dag_generator.schema import Task


class TaskManager:
    task_to_operator = {
        'bash': BashOperator,
    }

    @classmethod
    def add_task_mapping(cls, task_type: str, operator):
        """
        Add task/operator to index.

        Args:
            task_type: name of operator or task
            operator: operator/task class instance
        """
        cls.task_to_operator[task_type] = operator

    def generate_task(self, task_id: str, task_spec: Task):
        """
        Generate task/operator instance from config.

        Args:
            task_spec: task configuration
            task_id: id of task

        Returns:
            operator or task instance

        Raises:
            TaskTypeResolvingError: Raises an exception in case of nonexistent task
        """
        try:
            task = self.task_to_operator[task_spec.type]
        except KeyError:
            raise TaskTypeResolvingError(task_type=task_spec.type)

        if type(task) == _TaskDecorator:  # noqa: WPS516
            return task(**task_spec.kwargs)

        return task(
            task_id=task_id,
            **task_spec.kwargs,
        )
