import logging
from typing import Optional

from airflow.decorators import dag
from pydantic import ValidationError

from airflow_dag_generator.config_parser import ConfigParser
from airflow_dag_generator.dag_graph_builder import DAGGraphBuilder
from airflow_dag_generator.exceptions import (
    DifferentTasksAndFlowError,
    MissingFlowSpecError,
    MissingTasksSpecError,
    TaskTypeResolvingError,
    TooManyDagsError,
)
from airflow_dag_generator.task_manager import TaskManager


class DAGGenerator:

    def __init__(
        self,
        config_parser: Optional[ConfigParser] = None,
        dag_graph_builder: Optional[DAGGraphBuilder] = None,
    ):
        self.logger = logging.getLogger(__name__)
        self.config_parser = config_parser if config_parser else ConfigParser()
        self.dag_graph_builder = dag_graph_builder if dag_graph_builder else DAGGraphBuilder(TaskManager())

    def validate(self, config_path: str) -> bool:
        """
        Validate dag.

        Args:
            config_path: path to yaml config

        Returns:
            return is dag correct
        """
        try:
            self.generate(config_path)
        except (
                MissingFlowSpecError,
                MissingTasksSpecError,
                DifferentTasksAndFlowError,
                TaskTypeResolvingError,
                TooManyDagsError,
                ValidationError,
        ) as error:
            self.logger.error('Error in dag from "{config_path}" config: '.format(config_path=config_path) + str(error))
            return False
        self.logger.info('Successfully finish dag validation from "{config_path}" config'.format(
            config_path=config_path,
        ))
        return True

    def generate(self, config_path: str):
        """
        Generate airflow dag from yaml config.

        Return exactly one dag even if more passed in yaml file.

        Args:
            config_path: path to yaml config

        Returns:
            airflow dag instance
        """
        user_dag = self.config_parser.parse_config(config_path)

        @dag(
            dag_id=user_dag.dag_id,
            start_date=user_dag.start_date,
            doc_md=str(user_dag),
            template_searchpath=[user_dag.config_dir],
            **user_dag.kwargs,
        )
        def generated_dag():  # noqa: WPS430
            pipeline = self.dag_graph_builder.build_dag_graph(user_dag)
            pipeline  # noqa: WPS428

        return generated_dag()


def generate(config_path: str):
    dag_generator = DAGGenerator()
    return dag_generator.generate(config_path)
