from itertools import chain
from typing import Dict

import networkx as nx

from airflow_dag_generator.schema import DAG, TaskFlow
from airflow_dag_generator.task_manager import TaskManager


class DAGGraphBuilder:

    def __init__(self, task_manager: TaskManager):
        self.task_manager = task_manager if task_manager else TaskManager()

    def build_dag_graph(self, user_dag: DAG):
        """
        Builg airflow graph of Tasks.

        Args:
            user_dag: configuration of DAG

        Returns:
            airflow graph of tasks
        """
        dag_graph = self._build_graph(user_dag.flow)
        tasks_mapping = self._tasks_mapping(user_dag)
        return self._compile_tasks_qraph(dag_graph, tasks_mapping)

    def _build_graph(self, flow: Dict[str, TaskFlow]) -> nx.DiGraph:
        """
        Build networkx DiGraph from flow.

        Args:
            flow: mapping <task_id: task flow>

        Returns:
             networkx.DiGraph representation of dag
        """
        tasks_graph = nx.DiGraph()
        tasks_graph.add_nodes_from(list(flow.keys()))
        tasks_graph.add_edges_from(chain(*[
            [(depends_on, step_name) for depends_on in step.depends_on]
            for step_name, step in flow.items()
        ]))
        return tasks_graph

    def _tasks_mapping(self, user_dag: DAG):
        return {
            task_id: self.task_manager.generate_task(task_id, task)
            for task_id, task in user_dag.tasks.items()
        }

    def _compile_tasks_qraph(self, digraph: nx.DiGraph, tasks_mapping: dict):
        """
        Transform networkx Digraph to airflow graph.

        Args:
            digraph: networkx dag representation
            tasks_mapping: mapping <task_id: task>

        Returns:
            airflow graph of tasks
        """
        prev_layer = [root_node for root_node, degree in digraph.in_degree if degree == 0]
        task_dag = [tasks_mapping[root_node] for root_node in prev_layer]
        while digraph.nodes:
            edges = chain(*[list(digraph.out_edges(node)) for node in prev_layer])
            for edge in edges:
                source, target = edge
                task_dag.append(tasks_mapping[source] >> tasks_mapping[target])
            for node in prev_layer:
                digraph.remove_node(node)
            prev_layer = [new_root_node for new_root_node, degree in digraph.in_degree if degree == 0]
        return task_dag
